<script lang="ts">
  // Ordered-dither texture. A scalar field is sampled per cell and thresholded against a
  // Bayer matrix, so every mark is a full cell on the site grid. Animation advances in
  // discrete ticks only while motion is on; otherwise a single frame is drawn.
  import { onMount } from 'svelte';
  import { motion } from '$lib/motion.svelte';
  import { BAYER8, fbm } from '$lib/prng';
  type Mode = 'gradient' | 'noise' | 'bands' | 'checker' | 'rain';
  let { mode = 'gradient' as Mode, cell = 8, seed = 1, tick = 120, density = 1, label = '' }: { mode?: Mode; cell?: number; seed?: number; tick?: number; density?: number; label?: string } = $props();
  let canvas: HTMLCanvasElement;
  let host: HTMLElement;
  let frame = 0;
  let cols = 0, rows = 0, dpr = 1;
  let ctx: CanvasRenderingContext2D | null = null;
  let drawn = $state(false);
  let color = '#11110e';
  const field = (x: number, y: number, t: number): number => {
    switch (mode) {
      case 'gradient': { const d = (x / cols) * 0.7 + (y / rows) * 0.3; return Math.min(1, Math.max(0, 1.15 - d * 1.35 + (fbm(x / 9 + t * 0.03, y / 9, seed) - 0.5) * 0.35)); }
      case 'noise': return fbm(x / 7 + t * 0.05, y / 7 + t * 0.02, seed, 3);
      case 'bands': { const v = Math.sin((y - t * 0.5) / 3 + fbm(x / 12, y / 30, seed) * 4) * 0.5 + 0.5; return v * (0.35 + 0.65 * (x / cols)); }
      case 'checker': { const n = fbm(x / 10 - t * 0.02, y / 10, seed); return ((Math.floor(x / 2) + Math.floor(y / 2)) % 2 === 0 ? 0.62 : 0.38) * (0.5 + n); }
      case 'rain': { const speed = 1 + Math.floor(fbm(x / 3, 0, seed) * 3); const head = (t * speed + fbm(x, 0, seed) * rows * 4) % (rows * 1.6); const dist = head - y; return dist > 0 && dist < rows * 0.5 ? Math.max(0, 1 - dist / (rows * 0.5)) : 0; }
    }
  };
  function draw() {
    if (!ctx || !cols || !rows) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = color;
    const s = cell * dpr;
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      const v = field(x, y, frame) * density;
      if (v > (BAYER8[y & 7][x & 7] + 0.5) / 64) ctx.fillRect(x * s, y * s, s, s);
    }
    drawn = true;
  }
  function resize() {
    const r = host.getBoundingClientRect();
    dpr = Math.max(1, Math.min(3, Math.round(window.devicePixelRatio || 1)));
    cols = Math.floor(r.width / cell); rows = Math.floor(r.height / cell);
    canvas.width = cols * cell * dpr; canvas.height = rows * cell * dpr;
    canvas.style.width = cols * cell + 'px'; canvas.style.height = rows * cell + 'px';
    ctx = canvas.getContext('2d');
    color = getComputedStyle(host).color;
    draw();
  }
  onMount(() => {
    const ro = new ResizeObserver(resize); ro.observe(host);
    resize();
    return () => ro.disconnect();
  });
  $effect(() => {
    if (!motion.on) { frame = 0; draw(); return; }
    const id = setInterval(() => { frame++; draw(); }, tick);
    return () => clearInterval(id);
  });
</script>
<div class="dither" class:drawn bind:this={host} role={label ? 'img' : undefined} aria-label={label || undefined} aria-hidden={label ? undefined : 'true'}><canvas bind:this={canvas}></canvas></div>
<style>.dither{position:relative;width:100%;height:100%;overflow:hidden}.dither:not(.drawn){background:repeating-conic-gradient(currentColor 0 25%,transparent 0 50%) 0 0/16px 16px;opacity:.35}canvas{display:block;image-rendering:pixelated}</style>
