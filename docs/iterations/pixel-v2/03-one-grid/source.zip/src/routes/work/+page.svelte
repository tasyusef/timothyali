<script lang="ts">
  import PixImage from '$lib/components/PixImage.svelte';
  import Decode from '$lib/components/Decode.svelte';
  const projects = [
    { title: 'Pocketwatch', slug: 'pocketwatch', scope: 'Brand, product & front end', year: '2026', description: 'Brand identity, design system, and front-end for an all-in-one personal finance app: budgeting, net worth, and investments in one clean view.', alt: 'Pocketwatch campaign: budgeting and investing in one place, on electric lime', ext: 'png' },
    { title: 'PARC', slug: 'parc', scope: 'Cofounder · Brand & art direction', year: '2021–2026', description: 'Rebranding the NFT club I cofounded in 2021: logo, palette, pixel world, and a typeface, all from one 5×5 grid.', alt: 'PARC’s four-color pixel letters on a white sign floating in a pixel-cloud sky', ext: 'png' },
    { title: 'xrp.cafe', slug: 'xrpcafe', scope: 'Cofounder · Brand & motion', year: '2021–2024', description: 'Visual identity, motion design, and marketing for an NFT marketplace on the XRP Ledger.', alt: 'xrp.cafe coffee-mug logo lockup', ext: 'png' },
    { title: 'First Ledger', slug: 'firstledger', scope: 'Senior brand designer', year: '2024–2025', description: 'Complete visual identity system for a token trading platform on the XRP Ledger.', alt: 'First Ledger billboard mockup: The fastest way to trade', ext: 'jpg' }
  ];
</script>
<svelte:head><title>Selected work — Timothy Ali</title><meta name="description" content="Selected brand, product, motion, and front-end work by designer Timothy Ali." /></svelte:head>
<main class="inner-page" id="main" tabindex="-1">
  <section>
    <div class="meta lbl"><span>02 / Selected output</span><span>Brand / product / motion / code</span></div>
    <h1 class="page-head"><span class="display-l">Selected</span><span class="blackletter xl"><Decode text="work." step={70} /></span></h1>
    <div class="work-list">
      {#each projects as project, index}
        <article id={project.slug} class="rule">
          <div class="copy">
            <div class="project-meta lbl"><span>[{String(index + 1).padStart(2, '0')}]</span><span>{project.year}</span></div>
            <h2 class="display-s">{project.title}</h2>
            <p class="scope lbl">{project.scope}</p>
            <p class="body">{project.description}</p>
            <a class="cta lbl" href={`https://timothyali.com/work/${project.slug}`}>View case study <span class="mono" aria-hidden="true">-&gt;</span></a>
          </div>
          <a class="image" href={`https://timothyali.com/work/${project.slug}`} aria-label={`View ${project.title} case study`}>
            <PixImage src={`/work/${project.slug}.${project.ext}`} alt={project.alt} eager={index === 0} />
            <span class="image-label lbl" aria-hidden="true">Open -&gt;</span>
          </a>
        </article>
      {/each}
    </div>
    <footer class="page-foot lbl"><span>End of index / 004</span><a href="/contact/">Tell me what you’re building -&gt;</a></footer>
  </section>
</main>
<style>
.page-head{display:flex;flex-direction:column;gap:16px;padding-bottom:32px}
.xl{font-size:258px;line-height:258px;display:block}
article{display:grid;grid-template-columns:1fr 2fr;gap:32px;padding:32px 0;scroll-margin-top:16px}
.copy{display:flex;flex-direction:column;min-width:0}
.project-meta{display:flex;justify-content:space-between;margin-bottom:24px}
.scope{margin-top:8px}
.copy .body{margin:24px 0 32px}
.copy .cta{margin-top:auto;align-self:flex-start}
.image{position:relative;display:block;align-self:start;border:2px solid currentColor;background:var(--paper);color:var(--fg)}
.image-label{position:absolute;right:0;bottom:0;background:var(--fg);color:var(--paper);padding:8px 16px}
.image:hover{background:var(--fg);color:var(--paper)}
.image:hover .image-label{background:var(--paper);color:var(--fg)}
@media(max-width:1100px){.xl{font-size:172px;line-height:172px}}
@media(max-width:700px){.page-head{padding-bottom:24px}.xl{font-size:86px;line-height:86px}article{grid-template-columns:1fr;gap:16px;padding:24px 0}.image{order:-1}.copy .body{margin:16px 0 24px}}
</style>
