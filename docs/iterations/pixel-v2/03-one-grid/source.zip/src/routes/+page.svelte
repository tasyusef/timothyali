<script lang="ts">
  import Dither from '$lib/components/Dither.svelte';
  import Ascii from '$lib/components/Ascii.svelte';
  import Decode from '$lib/components/Decode.svelte';
  import Ticker from '$lib/components/Ticker.svelte';
  const projects = [
    ['01', 'Pocketwatch', 'Product / brand', 'pocketwatch'],
    ['02', 'PARC', 'Brand / pixel world', 'parc'],
    ['03', 'xrp.cafe', 'Brand / motion', 'xrpcafe'],
    ['04', 'First Ledger', 'Identity / system', 'firstledger']
  ];
  const qualities: [string, 'bands' | 'checker' | 'rain'][] = [['look.', 'bands'], ['move.', 'rain'], ['work.', 'checker']];
  const ticker = ['Brand', 'Product', 'Motion', 'Front end', 'From the first idea to something people use', 'Denver, CO', 'Think / make / repeat'];
</script>
<svelte:head><title>Timothy Ali — Designer & builder</title><meta name="description" content="I’m tim. Designer for teams that don’t have one yet. Brand, product, motion, front end." /></svelte:head>
<main id="main" tabindex="-1">
  <section class="hero" aria-labelledby="intro">
    <div class="hero-top">
      <h1 id="intro" class="blackletter hero-name"><Decode text="i’m tim." mode="type" step={110} delay={400} cursor /></h1>
      <div class="hero-field"><Dither mode="gradient" seed={3} tick={140} /></div>
    </div>
    <div class="meta lbl"><span>Independent designer / builder</span><span>Personal index — 001</span></div>
    <div class="hero-lower">
      <h2 class="display">Designer for teams<br />that don’t have<br />one yet</h2>
      <div class="hero-side">
        <p class="body">Brand. Product.<br />Motion. Front end.<br /><br />From the first idea<br />to something people use.</p>
        <a class="cta lbl" href="/work/">See my work <span class="mono" aria-hidden="true">-&gt;</span></a>
      </div>
    </div>
    <div class="ticker-row lbl rule"><Ticker items={ticker} /></div>
  </section>

  <section class="ink invested" aria-labelledby="invested">
    <div class="meta lbl"><span>01 / Personal commitment</span><span>No half measures.</span></div>
    <div class="stage">
      <h2 id="invested">
        <span class="display lead">I get</span>
        <span class="blackletter xl"><Decode text="invested." step={55} /></span>
        <span class="display tail">in what I make.</span>
      </h2>
      <div class="stage-field"><Ascii mode="noise" seed={11} density={0.6} /></div>
    </div>
    <div class="two rule">
      <pre class="mono diagram" aria-hidden="true">+---------------+
|  IDEA         |
|    |          |
|    v          |
|  ITERATE ---+ |
|    ^        | |
|    +--------+ |
|    |          |
|    v          |
|  SHIP.        |
+---------------+</pre>
      <p class="body">I’ve cofounded products.<br />Helped teams ship theirs.<br /><br />I care about the whole thing.</p>
    </div>
  </section>

  <section class="quality" aria-labelledby="quality-title">
    <div class="meta lbl"><h2 id="quality-title">02 / The whole thing</h2><span>Every detail counts.</span></div>
    {#each qualities as [word, mode], i}
      <div class="type-row">
        <span class="lbl code">[0{i + 1}]</span>
        <span class="lbl">How they</span>
        <span class="blackletter l"><Decode text={word} step={70} delay={i * 120} /></span>
        <div class="strip"><Dither {mode} seed={20 + i} cell={8} tick={100} /></div>
      </div>
    {/each}
  </section>

  <section class="work-index" aria-labelledby="work-title">
    <div class="meta lbl"><h2 id="work-title">03 / Selected output</h2><a href="/work/">All work -&gt;</a></div>
    {#each projects as [n, title, scope, slug]}
      <a class="index-row" href={`/work/#${slug}`}><span class="lbl">{n}</span><h3 class="display-s">{title}</h3><span class="lbl scope">{scope}</span><span class="mono" aria-hidden="true">-&gt;</span></a>
    {/each}
  </section>

  <section class="invitation" aria-labelledby="invite">
    <div class="meta lbl"><span>04 / Your move</span><span>Let’s make something.</span></div>
    <div class="invite-grid">
      <h2 id="invite"><span class="display">Tell me what<br />you’re</span><span class="blackletter xl"><Decode text="building." step={55} /></span></h2>
      <div class="invite-field"><Dither mode="rain" seed={5} tick={90} /></div>
    </div>
    <a class="cta-row lbl" href="/contact/">Get in touch <span class="mono" aria-hidden="true">-&gt;</span></a>
  </section>
</main>
<style>
.hero-top{display:grid;grid-template-columns:1fr 320px;gap:32px;padding:32px 0;align-items:end}
.hero-name{font-size:344px;line-height:344px;letter-spacing:0}
.hero-field{height:344px;border:2px solid currentColor}
.hero-lower{display:grid;grid-template-columns:1fr 320px;gap:32px;padding:32px 0}
.hero-side{display:flex;flex-direction:column;justify-content:space-between;gap:24px}
.hero-side .cta{align-self:flex-start}
.ticker-row{padding:8px 0;margin:0 calc(-1*var(--gutter));padding-left:var(--gutter)}
.invested{padding-bottom:64px}
.stage{display:grid;grid-template-columns:1fr 384px;gap:32px;padding:32px 0}
.stage h2{display:flex;flex-direction:column;gap:16px}
.lead{display:block}
.xl{font-size:258px;line-height:258px;display:block}
.tail{display:block;text-align:right}
.stage-field{border:2px solid currentColor;min-height:100%}
.two{display:grid;grid-template-columns:384px 1fr;gap:32px;padding-top:32px;align-items:end}
.diagram{white-space:pre}
.quality{padding-top:64px}
.meta h2{font:inherit;text-transform:inherit}
.type-row{display:grid;grid-template-columns:64px 128px 1fr 256px;gap:16px;align-items:center;padding:16px 0;border-bottom:2px solid currentColor}
.type-row .l{font-size:172px;line-height:172px}
.strip{height:172px;border:2px solid currentColor}
:global(.motion) .type-row:hover .l{transform:translateX(16px)}
.work-index{padding-top:64px}
.index-row{display:grid;grid-template-columns:64px 1fr 320px 32px;gap:16px;align-items:center;padding:24px 0;border-bottom:2px solid currentColor}
.index-row:hover{background:var(--fg);color:var(--paper);margin:0 calc(-1*var(--gutter));padding-left:var(--gutter);padding-right:var(--gutter)}
.index-row .mono{justify-self:end}
.invitation{padding-top:64px;padding-bottom:32px}
.invite-grid{display:grid;grid-template-columns:1fr 320px;gap:32px;padding:32px 0}
.invite-grid h2{display:flex;flex-direction:column;gap:16px}
.invite-field{border:2px solid currentColor}
@media(max-width:1100px){.hero-name{font-size:258px;line-height:258px}.hero-field{height:258px}.xl{font-size:172px;line-height:172px}.type-row .l{font-size:129px;line-height:129px}.strip{height:129px}.type-row{grid-template-columns:48px 96px 1fr 192px}}
@media(max-width:700px){
  .hero-top{grid-template-columns:1fr;gap:16px;padding:24px 0}
  .hero-name{font-size:129px;line-height:129px}
  .hero-field{height:96px}
  .hero-lower{grid-template-columns:1fr;gap:24px;padding:24px 0}
  .stage{grid-template-columns:1fr;gap:16px;padding:24px 0}
  .xl{font-size:86px;line-height:86px}
  .stage-field{height:128px}
  .two{grid-template-columns:1fr;gap:24px;padding-top:24px}
  .diagram{font-size:8px;line-height:8px}
  .type-row{grid-template-columns:40px 1fr 96px;gap:8px}
  .type-row .lbl:not(.code){display:none}
  .type-row .l{font-size:86px;line-height:86px}
  .strip{height:86px}
  .index-row{grid-template-columns:32px 1fr 32px;gap:8px;padding:16px 0}
  .index-row .scope{display:none}
  .invite-grid{grid-template-columns:1fr;gap:16px;padding:24px 0}
  .invite-field{height:96px}
  .quality,.work-index,.invitation{padding-top:40px}
  .invested{padding-bottom:40px}
}
</style>
