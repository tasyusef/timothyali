<script lang="ts">
  import Ascii from '$lib/components/Ascii.svelte';
  import Decode from '$lib/components/Decode.svelte';
</script>
<svelte:head><title>Get in touch — Timothy Ali</title><meta name="description" content="Tell me what you’re building. Connect with designer Timothy Ali about brand, product, motion, and front-end work." /></svelte:head>
<main class="inner-page" id="main" tabindex="-1">
  <section>
    <div class="meta lbl"><span>03 / Start a conversation</span><span>Human to human.</span></div>
    <div class="contact-grid page-head">
      <h1><span class="display">Tell me what<br />you’re</span><span class="blackletter xl"><Decode text="building." step={55} /></span></h1>
      <div class="field"><Ascii mode="fall" seed={3} density={0.9} tick={90} /></div>
    </div>
    <div class="detail rule">
      <p class="body">Got an idea, an early team, or something that needs a designer?<br /><br />I’d like to hear about it.</p>
      <a class="cta lbl" href="https://linkedin.com/in/timothyali">Message me on LinkedIn <span class="mono" aria-hidden="true">-&gt;</span></a>
    </div>
    <footer class="page-foot lbl"><span>Brand / product / motion / front end</span><a href="/work/">See my work -&gt;</a></footer>
  </section>
</main>
<style>
.contact-grid{display:grid;grid-template-columns:1fr 384px;gap:32px;align-items:stretch;padding-bottom:32px}
.contact-grid h1{display:flex;flex-direction:column;gap:16px}
.xl{font-size:258px;line-height:258px;display:block}
.field{border:2px solid currentColor}
.detail{display:grid;grid-template-columns:1fr 1fr;gap:32px;padding-top:32px;align-items:end}
.detail .body{max-width:40ch}
.detail .cta{justify-self:start}
@media(max-width:1100px){.xl{font-size:172px;line-height:172px}}
@media(max-width:700px){.contact-grid{grid-template-columns:1fr;gap:16px;padding-bottom:24px}.xl{font-size:86px;line-height:86px}.field{height:128px}.detail{grid-template-columns:1fr;gap:24px;padding-top:24px}}
</style>
