<script lang="ts">
  import '@fontsource/jacquard-24/400.css';
  import '@fontsource/jersey-25/400.css';
  import '@fontsource/jersey-15/400.css';
  import '@fontsource/silkscreen/400.css';
  import '@fontsource/press-start-2p/400.css';
  import '../app.css';
  import { page } from '$app/state';
  import { onMount } from 'svelte';
  import { motion, grid } from '$lib/motion.svelte';
  let { children } = $props();
  let explicit = false;
  let clock = $state('');
  const fmt = new Intl.DateTimeFormat('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'America/Denver' });
  function skipToContent(event: MouseEvent) {
    const main = document.getElementById('main'); if (!main) return;
    event.preventDefault(); main.focus({ preventScroll: true }); main.scrollIntoView({ behavior: 'instant', block: 'start' });
  }
  function toggleMotion() { motion.on = !motion.on; explicit = true; try { localStorage.setItem('tim-motion', motion.on ? 'on' : 'off'); } catch {} }
  function toggleGrid() { grid.on = !grid.on; try { localStorage.setItem('tim-grid', grid.on ? 'on' : 'off'); } catch {} }
  onMount(() => {
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    let saved: string | null = null; let g: string | null = null;
    try { saved = localStorage.getItem('tim-motion'); g = localStorage.getItem('tim-grid'); } catch {}
    explicit = saved === 'on' || saved === 'off';
    motion.on = explicit ? saved === 'on' : !media.matches;
    grid.on = g === 'on';
    motion.ready = true;
    const update = () => { if (!explicit) motion.on = !media.matches; };
    media.addEventListener('change', update);
    const tickClock = () => { clock = fmt.format(new Date()); };
    tickClock(); const id = setInterval(tickClock, 1000);
    return () => { media.removeEventListener('change', update); clearInterval(id); };
  });
  const route = $derived(page.url.pathname === '/' ? 'index' : page.url.pathname.replaceAll('/', ''));
</script>
<div class="site" class:motion={motion.on} class:show-grid={grid.on} data-motion={motion.on ? 'on' : 'off'}>
  <a class="skip-link lbl" href="#main" onclick={skipToContent}>Skip to content</a>
  <header class="site-header">
    <a class="wordmark blackletter" href="/" aria-label="Timothy Ali — home">Timothy Ali</a>
    <span class="path mono" aria-hidden="true">~/tim/{route}<span class="cursor"></span></span>
    <nav class="lbl" aria-label="Main navigation">
      <a href="/" aria-current={page.url.pathname === '/' ? 'page' : undefined}><b>01</b>Index</a>
      <a href="/work/" aria-current={page.url.pathname.startsWith('/work') ? 'page' : undefined}><b>02</b>Work</a>
      <a href="/contact/" aria-current={page.url.pathname.startsWith('/contact') ? 'page' : undefined}><b>03</b>Contact</a>
    </nav>
  </header>
  <div class="readout ink mono" aria-label="Status">
    <span>Design + build</span><span class="hide-m">Denver, CO</span><span class="hide-m">39.7392N 104.9903W</span><span>{clock ? `MT ${clock}` : 'MT --:--:--'}</span><span>SYS.OK</span>
  </div>
  {@render children()}
  <footer class="global-footer ink lbl">
    <span>(C) {new Date().getFullYear()} Timothy Ali <span class="hide-m">// A little human. A little machine.</span> // EOF</span>
    {#if motion.ready}<span class="controls"><button type="button" onclick={toggleMotion} aria-pressed={motion.on}>Motion [{motion.on ? 'on' : 'off'}]</button><button type="button" onclick={toggleGrid} aria-pressed={grid.on}>Grid [{grid.on ? 'on' : 'off'}]</button></span>{/if}
  </footer>
</div>
