<script lang="ts">
  // A solid page-colour ground under text that sits on a texture (decision 0066).
  // `pad` 'all' is 16px on every side; 'x' is the half plate the Work title uses.
  // `ground={false}` keeps the inset without the ground, so the title still floats.
  import type { Snippet } from 'svelte';
  let { as = 'div', pad = 'all', ground = true, class: klass = '', children, ...rest }:
    { as?: string; pad?: 'all' | 'x'; ground?: boolean; class?: string; children: Snippet; [key: string]: unknown } = $props();
  const cls = $derived(['plate', pad === 'x' ? 'plate-x' : '', ground ? '' : 'plate-bare', klass].filter(Boolean).join(' '));
</script>
<svelte:element this={as} class={cls} {...rest}>{@render children()}</svelte:element>
