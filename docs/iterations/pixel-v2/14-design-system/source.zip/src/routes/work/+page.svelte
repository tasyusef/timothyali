<script lang="ts">
  import Picture from '$lib/components/Picture.svelte';
  import Decode from '$lib/components/Decode.svelte';
  import Arrow from '$lib/components/Arrow.svelte';
  import Cta from '$lib/components/Cta.svelte';
  import IndexRow from '$lib/components/IndexRow.svelte';
  import MetaLine from '$lib/components/MetaLine.svelte';
  import PageFoot from '$lib/components/PageFoot.svelte';
  import Plate from '$lib/components/Plate.svelte';
  import { projects, count } from '$lib/work';
  import { STEP } from '$lib/tokens';
</script>
<svelte:head><title>Selected work — Timothy Ali</title><meta name="description" content="Selected brand, product, motion, and front-end work by designer Timothy Ali." /></svelte:head>
<main class="inner-page" id="main" tabindex="-1">
  <section>
    <header class="work-header">
      <h1 class="page-head"><span class="blackletter display-xl"><Decode text="work." step={STEP} /></span></h1>
      <IndexRow label="Project index" value={`01–${projects[projects.length - 1].n}`} layout="column" accent />
    </header>
    <div class="rows">
      {#each projects as p, i}
        <a id={p.slug} class="card row" href={`/work/${p.slug}/`}>
          <Picture src={p.cover.src} alt={p.cover.alt} eager={i < 2} />
          <div class="row-body">
            <MetaLine project={p} plate class="metadata" />
            <Plate as="h2" pad="x" ground={false} class="display">{p.title}</Plate>
            <Plate as="p" class="body">{p.description}</Plate>
            <Cta variant="quiet" class="lbl">View case study <Arrow /></Cta>
          </div>
        </a>
      {/each}
    </div>
    <PageFoot note={`End of index / ${count}`} href="/contact/" label="Tell me what you’re building" />
  </section>
</main>
<style>
.work-header{display:flex;align-items:flex-end;justify-content:space-between;gap:var(--s4);padding:var(--s2) 0 var(--s6)}
.page-head{display:flex;flex-direction:column;gap:var(--s2);min-width:0}
@media(max-width:700px){
  .work-header{flex-direction:column;align-items:stretch;gap:var(--s2);padding:var(--s1) 0 var(--s4)}
}
</style>
