<script lang="ts">
  import '@fontsource/jacquard-24/400.css';
  import '@fontsource/jersey-25/400.css';
  import '@fontsource/jersey-15/400.css';
  import '@fontsource/silkscreen/400.css';
  import '@fontsource/press-start-2p/400.css';
  import '../app.css';
  import { page } from '$app/state';
  import { afterNavigate } from '$app/navigation';
  import { onMount } from 'svelte';
  import { motion, grid, theme } from '$lib/motion.svelte';
  import Cursor from '$lib/components/Cursor.svelte';
  import { INK, WHITE } from '$lib/tokens';
  let { children } = $props();
  let explicit = false;
  let clock = $state('');
  let navCollapsed = $state(false);
  let headerHeight = $state(64);
  let headerElement: HTMLElement;
  let lastScroll = 0;
  afterNavigate(() => { navCollapsed = false; lastScroll = Math.max(0, window.scrollY); });
  const fmt = new Intl.DateTimeFormat('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'America/Denver' });
  function skipToContent(event: MouseEvent) {
    const main = document.getElementById('main'); if (!main) return;
    event.preventDefault(); main.focus({ preventScroll: true }); main.scrollIntoView({ behavior: 'instant', block: 'start' });
  }
  function toggleMotion() { motion.on = !motion.on; explicit = true; try { localStorage.setItem('tim-motion', motion.on ? 'on' : 'off'); } catch {} }
  function applyTheme() { document.documentElement.dataset.theme = theme.light ? 'light' : 'dark'; document.querySelector('meta[name=theme-color]')?.setAttribute('content', theme.light ? WHITE : INK); }
  function toggleTheme() { theme.light = !theme.light; try { localStorage.setItem('tim-theme', theme.light ? 'light' : 'dark'); } catch {} applyTheme(); }
  function toggleGrid() { grid.on = !grid.on; try { localStorage.setItem('tim-grid', grid.on ? 'on' : 'off'); } catch {} }
  onMount(() => {
    lastScroll = Math.max(0, window.scrollY);
    const measureHeader = () => { headerHeight = headerElement.offsetHeight; };
    measureHeader();
    const headerObserver = new ResizeObserver(measureHeader);
    headerObserver.observe(headerElement);
    const onScroll = () => {
      const y = Math.max(0, Math.min(window.scrollY, document.documentElement.scrollHeight - window.innerHeight));
      if (y <= headerHeight || y < lastScroll) navCollapsed = false;
      else if (y > lastScroll && !headerElement.contains(document.activeElement)) navCollapsed = true;
      lastScroll = y;
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    let saved: string | null = null; let g: string | null = null;
    try { saved = localStorage.getItem('tim-motion'); g = localStorage.getItem('tim-grid'); } catch {}
    explicit = saved === 'on' || saved === 'off';
    motion.on = explicit ? saved === 'on' : !media.matches;
    grid.on = g === 'on';
    theme.light = document.documentElement.dataset.theme === 'light';
    motion.ready = true;
    const update = () => { if (!explicit) motion.on = !media.matches; };
    media.addEventListener('change', update);
    const tickClock = () => { clock = fmt.format(new Date()); };
    tickClock(); const id = setInterval(tickClock, 1000);
    return () => { window.removeEventListener('scroll', onScroll); headerObserver.disconnect(); media.removeEventListener('change', update); clearInterval(id); };
  });
  const route = $derived(page.url.pathname === '/' ? 'index' : page.url.pathname.split('/').filter(Boolean).join('/'));
</script>
<div class="site" class:motion={motion.on} class:show-grid={grid.on} data-motion={motion.on ? 'on' : 'off'}>
  <a class="skip-link lbl" href="#main" onclick={skipToContent}>Skip to content</a>
  <div class="nav-chrome" class:collapsed={navCollapsed} style={`--header-height:${headerHeight}px`}>
  <header class="site-header" bind:this={headerElement}>
    <a class="wordmark blackletter" href="/" aria-label="Timothy Ali — home">timothy ali</a>
    <nav class="lbl" aria-label="Main navigation">
      <a href="/" aria-current={page.url.pathname === '/' ? 'page' : undefined}><b>01</b>Index</a>
      <a href="/work/" aria-current={page.url.pathname.startsWith('/work') ? 'page' : undefined}><b>02</b>Work</a>
      <a href="/contact/" aria-current={page.url.pathname.startsWith('/contact') ? 'page' : undefined}><b>03</b>Contact</a>
    </nav>
  </header>
  <div class="readout mono" aria-label="Status">
    <span class="path mono" aria-hidden="true"><span class="path-text">~/tim/{route}</span><Cursor /></span><span class="hide-m">Denver, CO</span><span class="hide-m">39.7392N 104.9903W</span><span>{clock ? `MT ${clock}` : 'MT --:--:--'}</span><span>SYS.OK</span>
  </div>
  </div>
  {@render children()}
  <footer class="global-footer lbl">
    <span class="dim">(C) {new Date().getFullYear()} Timothy Ali <span class="hide-m">// A little human. A little machine.</span> // EOF</span>
    {#if motion.ready}<span class="controls"><button type="button" onclick={toggleMotion} aria-pressed={motion.on}>Motion [{motion.on ? 'on' : 'off'}]</button><button type="button" onclick={toggleGrid} aria-pressed={grid.on}>Grid [{grid.on ? 'on' : 'off'}]</button><button type="button" onclick={toggleTheme} aria-pressed={theme.light}>Theme [{theme.light ? 'light' : 'dark'}]</button></span>{/if}
  </footer>
</div>
