<script lang="ts">
  import Dither from '$lib/components/Dither.svelte';
  import Ascii from '$lib/components/Ascii.svelte';
  import Decode from '$lib/components/Decode.svelte';
  import PixImage from '$lib/components/PixImage.svelte';
  const projects = [
    { n: '01', title: 'Pocketwatch', scope: 'Product / brand', slug: 'pocketwatch', ext: 'png', alt: 'Pocketwatch campaign: budgeting and investing in one place' },
    { n: '02', title: 'PARC', scope: 'Brand / pixel world', slug: 'parc', ext: 'png', alt: 'PARC’s four-color pixel letters on a white sign in a pixel-cloud sky' },
    { n: '03', title: 'xrp.cafe', scope: 'Brand / motion', slug: 'xrpcafe', ext: 'png', alt: 'xrp.cafe coffee-mug logo lockup' },
    { n: '04', title: 'First Ledger', scope: 'Identity / system', slug: 'firstledger', ext: 'jpg', alt: 'First Ledger billboard mockup: The fastest way to trade' }
  ];
  const qualities: [string, 'bands' | 'rain' | 'checker'][] = [['look.', 'bands'], ['move.', 'rain'], ['work.', 'checker']];
</script>
<svelte:head><title>Timothy Ali — Designer & builder</title><meta name="description" content="I’m tim. Designer for teams that don’t have one yet. Brand, product, motion, front end." /></svelte:head>
<main id="main" tabindex="-1">
  <section class="hero band" aria-labelledby="intro">
    <div class="band-bg"><Dither mode="sky" seed={3} tick={160} density={0.8} /></div>
    <h1 id="intro" class="blackletter hero-name"><Decode text="i’m tim." mode="type" step={110} delay={500} cursor /></h1>
    <span class="hero-hint lbl dim" aria-hidden="true">Scroll</span>
  </section>

  <section class="statement" aria-labelledby="statement-title">
    <h2 id="statement-title" class="display">Designer for teams<br />that don’t have<br />one yet</h2>
    <div class="statement-side">
      <p class="body">Brand. Product.<br />Motion. Front end.<br /><br />From the first idea<br />to something people use.</p>
      <a class="cta lbl" href="/work/">See my work <span class="mono" aria-hidden="true">-&gt;</span></a>
    </div>
  </section>

  <section class="invested band" aria-labelledby="invested">
    <div class="band-bg"><Ascii mode="noise" seed={11} density={0.42} tick={140} /></div>
    <h2 id="invested">
      <span class="display lead">I get</span>
      <span class="blackletter xl"><Decode text="invested." step={55} /></span>
      <span class="display tail">in what I make.</span>
    </h2>
  </section>

  <section class="proof">
    <pre class="mono diagram dim" aria-hidden="true">+---------------+
|  IDEA         |
|    |          |
|    v          |
|  ITERATE ---+ |
|    ^        | |
|    +--------+ |
|    |          |
|    v          |
|  SHIP.        |
+---------------+</pre>
    <p class="body">I’ve cofounded products.<br />Helped teams ship theirs.<br /><br />I care about the whole thing.</p>
  </section>

  <section class="quality" aria-label="How they look, move and work">
    {#each qualities as [word, mode], i}
      <div class="type-row">
        <span class="lbl dim">[0{i + 1}] How they</span>
        <span class="blackletter l"><Decode text={word} step={70} delay={i * 120} /></span>
        <div class="strip"><Dither {mode} seed={20 + i} cell={8} tick={100} /></div>
      </div>
    {/each}
  </section>

  <section class="work-index" aria-label="Selected work">
    <div class="cards">
      {#each projects as p, i}
        <a class="card" href={`/work/#${p.slug}`}>
          <PixImage src={`/work/${p.slug}.${p.ext}`} alt={p.alt} eager={i < 2} />
          <div class="card-body"><span class="lbl dim">{p.n} / {p.scope}</span><h3 class="display-s">{p.title}</h3><span class="mono" aria-hidden="true">-&gt;</span></div>
        </a>
      {/each}
    </div>
  </section>

  <section class="invitation" aria-labelledby="invite">
    <div class="invite-grid">
      <h2 id="invite"><span class="display">Tell me what<br />you’re</span><span class="blackletter xl"><Decode text="building." step={55} /></span></h2>
      <div class="invite-field"><Dither mode="rain" seed={5} tick={90} /></div>
    </div>
    <a class="cta-row lbl" href="/contact/">Get in touch <span class="mono" aria-hidden="true">-&gt;</span></a>
  </section>
</main>
<style>
.hero{min-height:calc(100vh - 96px);display:flex;flex-direction:column;justify-content:flex-end;padding-bottom:64px;overflow:hidden}
.hero-name{font-size:344px;line-height:344px}
.hero-hint{position:absolute;right:var(--gutter);bottom:64px}
.statement{display:grid;grid-template-columns:1fr 320px;gap:32px;padding-top:128px;padding-bottom:128px}
.statement-side{display:flex;flex-direction:column;justify-content:space-between;gap:32px}
.statement-side .cta{align-self:flex-start}
.invested{padding-top:64px;padding-bottom:96px;overflow:hidden}
.invested h2{display:flex;flex-direction:column;gap:16px}
.lead{display:block}
.xl{font-size:258px;line-height:258px;display:block}
.tail{display:block;text-align:right}
.proof{display:grid;grid-template-columns:384px 1fr;gap:32px;padding-top:96px;align-items:end}
.diagram{white-space:pre}
.quality{padding-top:160px}
.type-row{display:grid;grid-template-columns:192px 1fr 256px;gap:16px;align-items:center;padding:16px 0}
.type-row .l{font-size:172px;line-height:172px}
.strip{height:172px}
:global(.motion) .type-row:hover .l{transform:translateX(16px)}
.work-index{padding-top:160px}
.invitation{padding-top:160px;padding-bottom:64px}
.invite-grid{display:grid;grid-template-columns:1fr 320px;gap:32px;padding-bottom:32px}
.invite-grid h2{display:flex;flex-direction:column;gap:16px}
@media(max-width:1100px){.hero-name{font-size:258px;line-height:258px}.xl{font-size:172px;line-height:172px}.type-row .l{font-size:129px;line-height:129px}.strip{height:129px}.type-row{grid-template-columns:144px 1fr 192px}}
@media(max-width:700px){
  .hero{min-height:80vh;padding-bottom:48px}
  .hero-name{font-size:129px;line-height:129px}
  .hero-hint{display:none}
  .statement{grid-template-columns:1fr;gap:32px;padding-top:64px;padding-bottom:64px}
  .invested{padding-top:48px;padding-bottom:64px}
  .xl{font-size:86px;line-height:86px}
  .proof{grid-template-columns:1fr;gap:24px;padding-top:64px}
  .diagram{font-size:8px;line-height:8px}
  .type-row{grid-template-columns:1fr 96px;gap:8px}
  .type-row .lbl{display:none}
  .type-row .l{font-size:86px;line-height:86px}
  .strip{height:86px}
  .invite-grid{grid-template-columns:1fr;gap:16px;padding-bottom:16px}
  .invite-field{height:96px}
  .quality,.work-index,.invitation{padding-top:96px}
}
</style>
