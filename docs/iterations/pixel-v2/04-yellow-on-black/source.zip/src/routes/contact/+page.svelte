<script lang="ts">
  import Ascii from '$lib/components/Ascii.svelte';
  import Decode from '$lib/components/Decode.svelte';
</script>
<svelte:head><title>Get in touch — Timothy Ali</title><meta name="description" content="Tell me what you’re building. Connect with designer Timothy Ali about brand, product, motion, and front-end work." /></svelte:head>
<main class="inner-page" id="main" tabindex="-1">
  <section class="band contact">
    <div class="band-bg"><Ascii mode="fall" seed={3} density={0.42} tick={90} /></div>
    <h1 class="page-head"><span class="display">Tell me what<br />you’re</span><span class="blackletter xl"><Decode text="building." step={55} /></span></h1>
  </section>
  <section class="detail">
    <p class="body">Got an idea, an early team, or something that needs a designer?<br /><br />I’d like to hear about it.</p>
    <a class="cta lbl" href="https://linkedin.com/in/timothyali">Message me on LinkedIn <span class="mono" aria-hidden="true">-&gt;</span></a>
    <footer class="page-foot lbl dim"><span>Brand / product / motion / front end</span><a href="/work/">See my work -&gt;</a></footer>
  </section>
</main>
<style>
.contact{padding-bottom:96px;overflow:hidden}
.contact h1{display:flex;flex-direction:column;gap:16px}
.xl{font-size:258px;line-height:258px;display:block}
.detail{display:grid;grid-template-columns:1fr 1fr;gap:32px;padding-top:96px;align-items:end}
.detail .body{max-width:40ch}
.detail .cta{justify-self:start}
.detail .page-foot{grid-column:1/-1}
@media(max-width:1100px){.xl{font-size:172px;line-height:172px}}
@media(max-width:700px){.contact{padding-bottom:64px}.xl{font-size:86px;line-height:86px}.detail{grid-template-columns:1fr;gap:24px;padding-top:64px}}
</style>
