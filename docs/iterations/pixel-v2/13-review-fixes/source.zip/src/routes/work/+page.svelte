<script lang="ts">
  import Picture from '$lib/components/Picture.svelte';
  import Decode from '$lib/components/Decode.svelte';
  import { projects, count } from '$lib/work';
</script>
<svelte:head><title>Selected work — Timothy Ali</title><meta name="description" content="Selected brand, product, motion, and front-end work by designer Timothy Ali." /></svelte:head>
<main class="inner-page" id="main" tabindex="-1">
  <section>
    <header class="work-header">
      <h1 class="page-head"><span class="blackletter xl"><Decode text="work." step={70} /></span></h1>
      <div class="header-index lbl"><span>Project index</span><span class="range">01–{projects[projects.length - 1].n}</span></div>
    </header>
    <div class="rows">
      {#each projects as p, i}
        <a id={p.slug} class="card row" href={`/work/${p.slug}/`}>
          <Picture src={p.cover.src} alt={p.cover.alt} eager={i < 2} />
          <div class="row-body">
            <span class="lbl metadata">[{p.n}] / {p.year} / {p.scope}</span>
            <h2 class="display">{p.title}</h2>
            <p class="body">{p.description}</p>
            <span class="lbl more">View case study <span class="mono" aria-hidden="true">-&gt;</span></span>
          </div>
        </a>
      {/each}
    </div>
    <footer class="page-foot lbl dim"><span>End of index / {count}</span><a href="/contact/">Tell me what you’re building -&gt;</a></footer>
  </section>
</main>
<style>
.work-header{display:flex;align-items:flex-end;justify-content:space-between;gap:32px;padding:16px 0 48px}
.page-head{display:flex;flex-direction:column;gap:16px;min-width:0}
.header-index{display:flex;flex-direction:column;align-items:flex-end;gap:16px;padding-bottom:32px}
.header-index .range{font-size:32px;line-height:32px;color:var(--accent)}
.xl{font-size:258px;line-height:258px;display:block}
.rows{display:flex;flex-direction:column;gap:16px}
.row{display:grid;grid-template-columns:round(down,calc((100% - 32px) * 3 / 5),8px) 1fr;gap:32px;align-items:stretch;scroll-margin-top:16px}
.row-body{display:flex;flex-direction:column;gap:16px;min-width:0}
.row-body .metadata,.row-body .body{background:var(--paper);padding:16px}
.row-body .metadata{align-self:flex-start}
.row-body h2{padding:0 16px}
.row-body .more{display:inline-flex;align-items:center;gap:16px;align-self:flex-start;padding:16px}
.row-body .more .mono{color:var(--accent)}
.row:hover .more,.row:focus-visible .more{background:var(--accent);color:var(--on-accent)}
.row:hover .more .mono,.row:focus-visible .more .mono{color:var(--on-accent)}
@media(max-width:1300px){.row-body h2{font-size:41px;line-height:41px}}
@media(max-width:1100px){.xl{font-size:172px;line-height:172px}}
@media(max-width:900px){.row{grid-template-columns:100%;gap:16px}}
@media(max-width:700px){
  .work-header{flex-direction:column;align-items:stretch;gap:16px;padding:8px 0 32px}
  .header-index{flex-direction:row;align-items:baseline;justify-content:space-between;gap:16px;padding-bottom:0;white-space:nowrap}
  .header-index .range{font-size:16px;line-height:16px}
  .xl{font-size:129px;line-height:129px}
}
@media(max-width:380px){.xl{font-size:86px;line-height:86px}}
</style>
