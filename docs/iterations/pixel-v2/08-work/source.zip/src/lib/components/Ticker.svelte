<script lang="ts">
  // Horizontal type ticker that advances one grid cell per tick. Static when motion is off.
  import { onMount } from 'svelte';
  import { motion } from '$lib/motion.svelte';
  let { items, cell = 8, tick = 70 }: { items: string[]; cell?: number; tick?: number } = $props();
  let track: HTMLElement; let offset = $state(0); let half = 0;
  function measure() { half = track ? track.scrollWidth / 2 : 0; }
  onMount(() => { measure(); const ro = new ResizeObserver(measure); ro.observe(track); return () => ro.disconnect(); });
  $effect(() => { if (!motion.on) { offset = 0; return; } const id = setInterval(() => { offset = half ? (offset + cell) % half : 0; }, tick); return () => clearInterval(id); });
</script>
<div class="ticker" aria-hidden="true"><div class="track" bind:this={track} style:transform={`translateX(-${offset}px)`}>{#each [0, 1] as copy}{#each items as item}<span>{item}</span><span class="sep">/</span>{/each}{/each}</div></div>
<style>.ticker{overflow:hidden;white-space:nowrap}.track{display:inline-flex;will-change:transform}span{display:inline-block;padding:0 8px}</style>
