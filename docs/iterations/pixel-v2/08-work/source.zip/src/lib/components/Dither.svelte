<script lang="ts">
  // Ordered-dither texture. A scalar field is sampled per cell and thresholded against a
  // Bayer matrix, so every mark is a full cell on the site grid. The canvas origin is
  // snapped to the page's 8px grid, so cells line up with the layout wherever the band
  // starts. `avoid` names elements whose boxes knock the field out with a dithered
  // falloff, keeping type readable. Animation advances in discrete ticks only while
  // motion is on; otherwise a single frame is drawn.
  import { onMount } from 'svelte';
  import { motion, theme } from '$lib/motion.svelte';
  import { BAYER8, fbm } from '$lib/prng';
  import { knockout, measureBoxes, type Box } from '$lib/knockout';
  type Mode = 'gradient' | 'sky' | 'noise' | 'bands' | 'checker' | 'rain';
  let { mode = 'gradient' as Mode, cell = 8, seed = 1, tick = 120, density = 1, label = '', avoid = '', pad = 2, feather = 6, fadeIn = 0, fadeOut = 0 }: { mode?: Mode; cell?: number; seed?: number; tick?: number; density?: number; label?: string; avoid?: string; pad?: number; feather?: number; fadeIn?: number; fadeOut?: number } = $props();
  let canvas: HTMLCanvasElement;
  let host: HTMLElement;
  let frame = 0;
  let cols = 0, rows = 0, dpr = 1, offX = 0, offY = 0;
  let ctx: CanvasRenderingContext2D | null = null;
  let drawn = $state(false);
  let color = '#11110e';
  let boxes: Box[] = [];
  const field = (x: number, y: number, t: number): number => {
    switch (mode) {
      case 'gradient': { const d = (x / cols) * 0.7 + (y / rows) * 0.3; return Math.min(1, Math.max(0, 1.15 - d * 1.35 + (fbm(x / 9 + t * 0.03, y / 9, seed) - 0.5) * 0.35)); }
      case 'sky': { const d = (x / cols) * 0.55 + (1 - y / rows) * 0.6 - 0.28; return Math.min(1, Math.max(0, d + (fbm(x / 10 + t * 0.03, y / 10, seed) - 0.5) * 0.4)); }
      case 'noise': return fbm(x / 7 + t * 0.05, y / 7 + t * 0.02, seed, 3);
      case 'bands': { const v = Math.sin((y - t * 0.5) / 3 + fbm(x / 12, y / 30, seed) * 4) * 0.5 + 0.5; return v * (0.2 + 0.8 * (1 - x / cols)); }
      case 'checker': { const n = fbm(x / 10 - t * 0.02, y / 10, seed); return ((Math.floor(x / 2) + Math.floor(y / 2)) % 2 === 0 ? 0.62 : 0.38) * (0.5 + n); }
      case 'rain': { const speed = 1 + Math.floor(fbm(x / 3, 0, seed) * 3); const head = (t * speed + fbm(x, 0, seed) * rows * 4) % (rows * 1.6); const dist = head - y; return dist > 0 && dist < rows * 0.5 ? Math.max(0, 1 - dist / (rows * 0.5)) : 0; }
    }
  };
  // fade the field in over the first `fadeIn` rows and out over the last `fadeOut` rows,
  // so two bands can overlap and interleave through the same threshold
  const edge = (row: number) => { let e = 1; if (fadeIn > 0) e *= Math.min(1, Math.max(0, (row + 0.5) / fadeIn)); if (fadeOut > 0) { const h = (host.clientHeight) / cell; e *= Math.min(1, Math.max(0, (h - row - 0.5) / fadeOut)); } return e; };
  function measure() {
    if (!avoid) { boxes = []; return; }
    boxes = measureBoxes(host.closest('.band') ?? document, avoid, canvas.getBoundingClientRect(), cell);
  }
  function draw() {
    if (!ctx || !cols || !rows) return;
    measure();
    color = getComputedStyle(host).color;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = color;
    const s = cell * dpr;
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      const v = field(x, y, frame) * density * knockout(x + 0.5, y + 0.5, boxes, pad, feather) * edge(y - offY / cell);
      if (v > (BAYER8[(y + offY / cell) & 7][(x + offX / cell) & 7] + 0.5) / 64) ctx.fillRect(x * s, y * s, s, s);
    }
    drawn = true;
  }
  function resize() {
    const r = host.getBoundingClientRect();
    dpr = Math.max(1, Math.min(3, Math.round(window.devicePixelRatio || 1)));
    // snap the canvas origin back to the page's 8px grid
    const pageX = r.left + window.scrollX, pageY = r.top + window.scrollY;
    const g = Math.max(cell, 8);
    offX = ((pageX % g) + g) % g; offY = ((pageY % g) + g) % g;
    cols = Math.ceil((r.width + offX) / cell); rows = Math.ceil((r.height + offY) / cell);
    canvas.width = cols * cell * dpr; canvas.height = rows * cell * dpr;
    canvas.style.width = cols * cell + 'px'; canvas.style.height = rows * cell + 'px';
    canvas.style.left = -offX + 'px'; canvas.style.top = -offY + 'px';
    ctx = canvas.getContext('2d');
    color = getComputedStyle(host).color;
    draw();
  }
  onMount(() => {
    const ro = new ResizeObserver(resize); ro.observe(host); ro.observe(document.body);
    resize();
    document.fonts?.ready.then(resize);
    return () => ro.disconnect();
  });
  $effect(() => { void theme.light; draw(); });
  $effect(() => {
    if (!motion.on) { frame = 0; draw(); return; }
    const id = setInterval(() => { frame++; draw(); }, tick);
    return () => clearInterval(id);
  });
</script>
<div class="dither" class:drawn bind:this={host} role={label ? 'img' : undefined} aria-label={label || undefined} aria-hidden={label ? undefined : 'true'}><canvas bind:this={canvas}></canvas></div>
<style>.dither{position:relative;width:100%;height:100%;overflow:hidden}.dither:not(.drawn){background:repeating-conic-gradient(currentColor 0 25%,transparent 0 50%) 0 0/16px 16px;opacity:.35}canvas{position:absolute;left:0;top:0;display:block;image-rendering:pixelated}</style>
