<script lang="ts">
  import Picture from '$lib/components/Picture.svelte';
  import Clip from '$lib/components/Clip.svelte';
  import Decode from '$lib/components/Decode.svelte';
  import { rowColumns, count, type Row } from '$lib/work';
  import { onMount } from 'svelte';
  let { data } = $props();
  const p = $derived(data.project);
  const next = $derived(data.next);
  // The title is one blackletter word that cannot wrap. A hidden probe at the
  // heading's own size measures it; when it would not fit, the word drops one
  // step down the cell table (172 → 86, 86 → 43) instead of overflowing.
  let h1: HTMLElement; let probe: HTMLElement;
  let small = $state(false);
  function fit() { if (h1 && probe) small = probe.scrollWidth > h1.clientWidth; }
  onMount(() => {
    fit(); document.fonts?.ready.then(fit);
    const ro = new ResizeObserver(fit); ro.observe(h1);
    return () => ro.disconnect();
  });
</script>
<svelte:head><title>{p.title} — Timothy Ali</title><meta name="description" content={p.description} /></svelte:head>

{#snippet gallery(rows: Row[], eager: boolean)}
  {#each rows as row}
    <div class="grow" style:--cols={rowColumns(row)}>
      {#each row as m}
        {#if m.video}<Clip src={m.src} width={m.w} height={m.h} label={m.alt} />{:else}<Picture src={m.src} x2={m.x2} alt={m.alt} width={m.w} height={m.h} {eager} />{/if}
      {/each}
    </div>
  {/each}
{/snippet}

<main class="inner-page study" id="main" tabindex="-1">
  <section class="head">
    <a class="back lbl" href="/work/"><span class="mono" aria-hidden="true">&lt;-</span> Work</a>
    <span class="lbl">[{p.n}] / {p.year} / {p.scope}</span>
    <h1 class="blackletter title" class:small bind:this={h1}><span class="probe" aria-hidden="true" bind:this={probe}>{p.word}</span><Decode text={p.word} step={70} /></h1>
    <div class="intro">
      <div class="lead-col">{#each p.lead as para}<p class="lead">{para}</p>{/each}</div>
      <dl class="meta">
        <div><dt class="lbl dim">Role</dt><dd class="body">{p.role}</dd></div>
        {#if p.timeline}<div><dt class="lbl dim">Timeline</dt><dd class="body">{p.timeline}</dd></div>{/if}
        <div><dt class="lbl dim">Tools</dt><dd class="body">{p.tools}</dd></div>
        {#if p.live}<div><dt class="lbl dim">Live</dt><dd class="body"><a class="link" href={p.live.href}>{p.live.label} <span class="mono" aria-hidden="true">-&gt;</span></a></dd></div>{/if}
      </dl>
    </div>
  </section>

  <section class="gallery hero-row">{@render gallery([p.hero], true)}</section>

  {#each p.blocks as block}
    {#if block.type === 'text'}
      <section class="text"><h2 class="display-s">{block.title}</h2><div class="paras">{#each block.paras as para}<p class="body">{para}</p>{/each}</div></section>
    {:else if block.type === 'gallery'}
      <section class="gallery">{#if block.note}<span class="lbl dim note">{block.note}</span>{/if}{@render gallery(block.rows, false)}</section>
    {:else}
      <section class="list"><h2 class="display-s">{block.title}</h2><ol>{#each block.items as item, i}<li><span class="lbl">{String(i + 1).padStart(2, '0')}</span><span class="body">{item}</span></li>{/each}</ol></section>
    {/if}
  {/each}

  <section class="next">
    <a class="cta-row lbl" href={`/work/${next.slug}/`}><span>Next / [{next.n}]</span><span>{next.title} <span class="mono" aria-hidden="true">-&gt;</span></span></a>
    <footer class="page-foot lbl dim"><span>[{p.n}] / {count}</span><a href="/contact/">Tell me what you’re building -&gt;</a></footer>
  </section>
</main>
<style>
.head{display:flex;flex-direction:column;gap:16px;padding-top:32px}
.back{display:inline-flex;align-items:center;gap:8px;align-self:flex-start;padding:8px 0}
.back:hover{color:var(--accent)}
.title{position:relative;font-size:172px;line-height:172px;margin-top:16px}
.title .probe{position:absolute;left:0;top:0;width:0;overflow:hidden;visibility:hidden;white-space:pre;pointer-events:none}
.title.small :global(.decode){font-size:86px;line-height:86px}
.intro{display:grid;grid-template-columns:round(down,calc((100% - 32px) * 2 / 3),8px) 1fr;gap:32px;margin-top:32px;align-items:start}
.lead-col{display:flex;flex-direction:column;gap:24px}
.meta{display:flex;flex-direction:column;gap:16px;margin:0;padding-top:8px}
.meta dt{margin-bottom:8px}.meta dd{margin:0}
.link{display:inline-flex;align-items:center;gap:8px}.link:hover{color:var(--accent)}
.hero-row{padding-top:64px}
.text,.list,.gallery{padding-top:64px}
.text,.list{display:grid;grid-template-columns:round(down,calc((100% - 32px) / 2),8px) 1fr;gap:32px;align-items:start}
.paras{display:flex;flex-direction:column;gap:24px}
.gallery{display:flex;flex-direction:column;gap:16px}
.gallery .note{margin-bottom:8px}
.grow{display:grid;grid-template-columns:var(--cols);gap:16px;align-items:start}
.list ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:16px}
.list li{display:grid;grid-template-columns:48px 1fr;gap:16px;align-items:baseline}
.next{padding-top:64px}
@media(max-width:1100px){.title{font-size:129px;line-height:129px}}
@media(max-width:900px){.title{font-size:86px;line-height:86px}.title.small :global(.decode){font-size:43px;line-height:43px}.intro,.text,.list{grid-template-columns:100%}}
@media(max-width:700px){
  .head{padding-top:24px}
  .intro{margin-top:24px;gap:24px}
  .grow{grid-template-columns:100%}
  .hero-row,.text,.list,.gallery,.next{padding-top:48px}
}
</style>
