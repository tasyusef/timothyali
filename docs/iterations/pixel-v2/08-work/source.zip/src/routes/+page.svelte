<script lang="ts">
  import Ascii from '$lib/components/Ascii.svelte';
  import Decode from '$lib/components/Decode.svelte';
  import Picture from '$lib/components/Picture.svelte';
  import { projects } from '$lib/work';
  const qualities: [string, string][] = [['looks.', 'Brand'], ['moves.', 'Motion'], ['works.', 'Product / front end']];
</script>
<svelte:head><title>Timothy Ali — Designer & builder</title><meta name="description" content="I’m tim. Designer for teams that don’t have one yet. Brand, product, motion, front end." /></svelte:head>
<main id="main" tabindex="-1">
  <section class="hero band" aria-labelledby="intro">
    <div class="band-bg"><Ascii mode="sky" seed={3} tick={160} density={0.9} avoid=".hero-hint" /></div>
    <h1 id="intro" class="blackletter hero-name"><Decode text="i’m tim." mode="type" step={110} delay={500} cursor /></h1>
    <span class="hero-hint lbl" aria-hidden="true">Scroll<svg class="arrow" width="16" height="16" viewBox="0 0 8 8" shape-rendering="crispEdges" aria-hidden="true"><path d="M3 0h1v1h-1zM3 1h1v1h-1zM3 2h1v1h-1zM3 3h1v1h-1zM3 4h1v1h-1zM3 5h1v1h-1zM3 6h1v1h-1zM3 7h1v1h-1zM0 4h1v1h-1zM6 4h1v1h-1zM1 5h1v1h-1zM5 5h1v1h-1zM2 6h1v1h-1zM4 6h1v1h-1z" fill="currentColor" /></svg></span>
  </section>

  <section class="who" aria-labelledby="statement-title">
    <h2 id="statement-title" class="para">
      <span class="display">Designer for teams that don’t <br class="hide-m" />have one yet. I care how it</span>
      <span class="words">{#each qualities as [word, label], i}<span class="blackletter w"><Decode text={word} step={70} delay={i * 150} /></span><span class="lbl note" aria-hidden="true">{label}</span>{/each}</span>
    </h2>
    <p class="sr-only">Looks: brand. Moves: motion. Works: product and front end.</p>
    <div class="who-foot">
      <p class="body">I’ve cofounded products.<br />Helped teams ship theirs.</p>
      <a class="cta lbl" href="/work/">See my work <span class="mono" aria-hidden="true">-&gt;</span></a>
    </div>
  </section>

  <section class="work-index" aria-labelledby="work-title">
    <div class="index-head"><h2 id="work-title" class="display">Selected work</h2><span class="lbl" aria-hidden="true">01–{projects[projects.length - 1].n}</span></div>
    <div class="cards">
      {#each projects as p, i}
        <a class="card" href={`/work/${p.slug}/`}>
          <Picture src={p.cover.src} alt={p.cover.alt} eager={i < 3} />
          <div class="card-body"><span class="lbl">{p.n} / {p.scope}</span><h3 class="display-s">{p.title}</h3><span class="mono" aria-hidden="true">-&gt;</span></div>
        </a>
      {/each}
    </div>
  </section>

  <section class="invitation band" aria-labelledby="invite">
    <div class="band-bg"><Ascii mode="fall" seed={5} tick={90} density={0.7} avoid=".invitation h2 > span, .invitation .cta-row" /></div>
    <h2 id="invite"><span class="display">Tell me what<br />you’re</span><span class="blackletter xl"><Decode text="building." step={55} /></span></h2>
    <a class="cta-row lbl" href="/contact/">Get in touch <span class="mono" aria-hidden="true">-&gt;</span></a>
  </section>
</main>
<style>
.hero{min-height:calc(100vh - 96px);min-height:round(down,calc(100vh - 96px),8px);display:flex;flex-direction:column;justify-content:flex-end;padding-bottom:64px;overflow:hidden}
.hero-name{font-size:344px;line-height:344px}
.hero-hint{position:absolute;right:var(--gutter);bottom:64px;display:inline-flex;align-items:center;gap:8px;padding:8px 16px;background:var(--accent);color:var(--on-accent)}
.hero-hint .arrow{display:block;transform:translateY(0)}
:global(.motion) .hero-hint .arrow{animation:nudge 1s steps(2,jump-none) infinite}
@keyframes nudge{from{transform:translateY(0)}to{transform:translateY(2px)}}
.who{padding-top:64px;padding-bottom:64px}
.para{font-size:82px;line-height:128px}
.para .display{display:inline;font-size:82px;line-height:128px}
.words{display:block;font-size:129px;line-height:128px}
.para .w{font-size:129px;line-height:128px;display:inline;margin-right:24px}
.para .note{display:inline-block;vertical-align:baseline;margin-right:32px}
.who-foot{display:flex;justify-content:space-between;align-items:flex-end;gap:32px;margin-top:64px}
.xl{font-size:258px;line-height:258px;display:block}
.work-index{padding-top:64px;padding-bottom:64px}
.index-head{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;padding-bottom:32px}
.invitation{padding-top:64px;padding-bottom:64px;overflow:hidden}
.invitation h2{display:flex;flex-direction:column;gap:16px;padding-bottom:64px}
@media(max-width:1100px){.hero-name{font-size:258px;line-height:258px}.xl{font-size:172px;line-height:172px}.words,.para .w{font-size:86px}}
@media(max-width:700px){
  .hero{min-height:80vh;min-height:round(down,80vh,8px);padding-bottom:48px}
  .hero-name{font-size:129px;line-height:129px}
  .hero-hint{position:static;margin-top:16px;align-self:flex-start}
  .who{padding-top:48px;padding-bottom:48px}
  .para{font-size:41px;line-height:64px}.para .display{font-size:41px;line-height:64px}.words,.para .w{font-size:86px;line-height:96px}.para .w{margin-right:8px}.para .note{margin-right:16px}
  .xl{font-size:86px;line-height:86px}
  .who-foot{flex-direction:column;align-items:flex-start;margin-top:48px}
  .invitation{padding-top:48px;padding-bottom:48px}
  .invitation h2{padding-bottom:32px}
  .work-index{padding-top:48px;padding-bottom:48px}
}
</style>
