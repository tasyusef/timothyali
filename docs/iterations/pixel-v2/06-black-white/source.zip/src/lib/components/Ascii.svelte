<script lang="ts">
  // ASCII field. Each 16px cell holds a 5×7 bitmap glyph drawn with 2px pixels, chosen
  // from a density ramp by a noise field. Runs in discrete ticks while motion is on.
  import { onMount } from 'svelte';
  import { motion } from '$lib/motion.svelte';
  import { fbm, hash2 } from '$lib/prng';
  import { GLYPHS, RAMP } from '$lib/glyphs';
  import { knockout, measureBoxes, type Box } from '$lib/knockout';
  type Mode = 'noise' | 'fall' | 'scan' | 'sparse';
  let { mode = 'noise' as Mode, cell = 16, px = 2, seed = 7, tick = 110, density = 1, avoid = '', pad = 1, feather = 3 }: { mode?: Mode; cell?: number; px?: number; seed?: number; tick?: number; density?: number; avoid?: string; pad?: number; feather?: number } = $props();
  let canvas: HTMLCanvasElement; let host: HTMLElement;
  let ctx: CanvasRenderingContext2D | null = null;
  let drawn = $state(false);
  let cols = 0, rows = 0, dpr = 1, frame = 0, color = '#11110e', offX = 0, offY = 0;
  let boxes: Box[] = [];
  function measure() {
    if (!avoid) { boxes = []; return; }
    boxes = measureBoxes(host.closest('.band') ?? document, avoid, canvas.getBoundingClientRect(), cell);
  }
  const pick = (x: number, y: number, t: number): string => {
    let v: number;
    if (mode === 'noise') v = fbm(x / 6 + t * 0.04, y / 4 - t * 0.015, seed, 2);
    else if (mode === 'fall') { const sp = 1 + Math.floor(hash2(x, 0, seed) * 3); const head = (t * sp * 0.5 + hash2(x, 1, seed) * rows * 3) % (rows * 1.8); const d = head - y; v = d > 0 && d < rows * 0.6 ? 1 - d / (rows * 0.6) : 0; if (d > 0 && d < 1) return '0'; }
    else if (mode === 'scan') { const line = Math.abs(((t * 0.7) % (rows + 6)) - 3 - y); v = Math.max(0, 1 - line / 3) * 0.8 + fbm(x / 8, y / 8, seed) * 0.25; }
    else { v = hash2(x, y, seed + Math.floor(t / 6)) > 0.93 ? fbm(x, y, seed) : 0; }
    v *= density * knockout(x + 0.5, y + 0.5, boxes, pad, feather);
    const i = Math.min(RAMP.length - 1, Math.floor(v * RAMP.length));
    return RAMP[i];
  };
  function drawGlyph(ch: string, cx: number, cy: number) {
    const g = GLYPHS[ch]; if (!g || !ctx) return;
    const p = px * dpr; const ox = cx + Math.floor((cell * dpr - 5 * p) / 2 / p) * p; const oy = cy + Math.floor((cell * dpr - 7 * p) / 2 / p) * p;
    for (let r = 0; r < 7; r++) { const bits = g[r]; for (let c = 0; c < 5; c++) if (bits & (16 >> c)) ctx.fillRect(ox + c * p, oy + r * p, p, p); }
  }
  function draw() {
    if (!ctx || !cols || !rows) return;
    measure();
    ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = color;
    const s = cell * dpr;
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) { const ch = pick(x, y, frame); if (ch !== ' ') drawGlyph(ch, x * s, y * s); }
    drawn = true;
  }
  function resize() {
    const r = host.getBoundingClientRect(); dpr = Math.max(1, Math.min(3, Math.round(window.devicePixelRatio || 1)));
    const pageX = r.left + window.scrollX, pageY = r.top + window.scrollY; const g = cell;
    offX = ((pageX % g) + g) % g; offY = ((pageY % g) + g) % g;
    cols = Math.ceil((r.width + offX) / cell); rows = Math.ceil((r.height + offY) / cell);
    canvas.width = cols * cell * dpr; canvas.height = rows * cell * dpr; canvas.style.width = cols * cell + 'px'; canvas.style.height = rows * cell + 'px';
    canvas.style.left = -offX + 'px'; canvas.style.top = -offY + 'px';
    ctx = canvas.getContext('2d'); color = getComputedStyle(host).color; draw();
  }
  onMount(() => { const ro = new ResizeObserver(resize); ro.observe(host); ro.observe(document.body); resize(); document.fonts?.ready.then(resize); return () => ro.disconnect(); });
  $effect(() => { if (!motion.on) { frame = 0; draw(); return; } const id = setInterval(() => { frame++; draw(); }, tick); return () => clearInterval(id); });
</script>
<div class="ascii" class:drawn bind:this={host} aria-hidden="true"><canvas bind:this={canvas}></canvas></div>
<style>.ascii{position:relative;width:100%;height:100%;overflow:hidden}.ascii:not(.drawn){background:repeating-conic-gradient(currentColor 0 25%,transparent 0 50%) 0 0/16px 16px;opacity:.35}canvas{position:absolute;left:0;top:0;display:block;image-rendering:pixelated}</style>
