<script lang="ts">
  const rows = [
    '0000001100000000','0100001100000100','0011001100011000','0001101100110000',
    '0000111111100000','1111110011111100','1111100001111100','0000111111100000',
    '0001101100110000','0011001100011000','0100001100000100','0000001100000000'
  ];
</script>
<svg viewBox="0 0 128 96" fill="currentColor" aria-hidden="true" shape-rendering="crispEdges">
  {#each rows as row,y}{#each [...row] as bit,x}{#if bit === '1'}<rect x={x*8} y={y*8} width="8" height="8" />{/if}{/each}{/each}
</svg>
<style>svg{display:block;width:100%;height:auto}</style>
