<script lang="ts">
  import PixelMark from '$lib/components/PixelMark.svelte';
  import { onMount } from 'svelte';
  let field: HTMLElement;
  onMount(()=>{
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{entry.target.classList.toggle('in-view',entry.isIntersecting)}),{threshold:.2});
    field.querySelectorAll('[data-kinetic]').forEach(el=>observer.observe(el));
    return ()=>observer.disconnect();
  });
  const projects=[['01','Pocketwatch','PRODUCT / BRAND','pocketwatch'],['02','PARC','BRAND / PIXEL WORLD','parc'],['03','xrp.cafe','BRAND / MOTION','xrpcafe'],['04','First Ledger','IDENTITY / SYSTEM','firstledger']];
</script>
<svelte:head><title>Timothy Ali — Designer & builder</title><meta name="description" content="I’m tim. Designer for teams that don’t have one yet. Brand, product, motion, front end." /></svelte:head>
<main id="main" tabindex="-1" bind:this={field}>
  <section class="hero" aria-labelledby="intro">
    <div class="section-meta"><span>INDEPENDENT DESIGNER / BUILDER</span><span>PERSONAL INDEX — 001</span></div>
    <div class="hero-name"><h1 id="intro" class="blackletter">i’m tim<span class="period">.</span></h1><div class="pixel-symbol" aria-hidden="true"><PixelMark /><span>[ HUMAN INPUT REQUIRED ]</span></div></div>
    <div class="hero-bottom"><h2 class="display">Designer for teams<br />that don’t have<br />one yet<span class="cursor" aria-hidden="true">_</span><span class="sr-only">.</span></h2><div class="hero-side"><p>Brand. Product.<br />Motion. Front end.<br /><br />From the first idea<br />to something people use.</p><a class="arrow-link" href="/work/">See my work <span aria-hidden="true">↗</span></a></div></div>
    <div class="hero-foot"><span>SCROLL TO CONTINUE ↓</span><span class="barcode" aria-hidden="true">▌▐▌▌▐▐▌▐▌▌▌▐▌</span><span>THINK / MAKE / REPEAT</span></div>
  </section>
  <section class="investment" aria-labelledby="invested">
    <div class="section-meta"><span>01 / PERSONAL COMMITMENT</span><span>NO HALF MEASURES.</span></div>
    <h2 id="invested"><span class="display lead">I get</span><span class="blackletter kinetic-word" data-kinetic>invested.</span><span class="display tail">in what I make.</span></h2>
    <div class="ascii-note"><pre aria-hidden="true">┌─────────────┐
│ IDEA        │
│   ↓         │
│ ITERATE ─┐  │
│   ↑      │  │
│   └──────┘  │
│   ↓         │
│ SHIP.       │
└─────────────┘</pre><p>I’ve cofounded products.<br />Helped teams ship theirs.<br /><br />I care about the whole thing.</p></div>
  </section>
  <section class="quality" aria-labelledby="quality-title">
    <div class="section-meta"><h2 id="quality-title">02 / THE WHOLE THING</h2><span>EVERY DETAIL COUNTS.</span></div>
    {#each ['look.','move.','work.'] as word,i}<div class="type-row" data-kinetic><span class="row-code">[0{i+1}]</span><span class="row-label">HOW THEY</span><span class="blackletter row-word">{word}</span><span class="row-end" aria-hidden="true">{['+','→','×'][i]}</span></div>{/each}
  </section>
  <section class="work-index" aria-labelledby="work-title"><div class="section-meta"><h2 id="work-title">03 / SELECTED OUTPUT</h2><a href="/work/">ALL WORK ↗</a></div>{#each projects as project}<a class="index-row" href={`/work/#${project[3]}`}><span>{project[0]}</span><h3>{project[1]}</h3><span class="scope">{project[2]}</span><span aria-hidden="true">↗</span></a>{/each}</section>
  <section class="invitation"><div class="section-meta"><span>04 / YOUR MOVE</span><span>LET’S MAKE SOMETHING.</span></div><h2><span class="display">Tell me what<br />you’re</span> <span class="blackletter" data-kinetic>building.</span></h2><a class="arrow-link" href="/contact/">Get in touch <span aria-hidden="true">↗</span></a></section>
</main>
<style>
.hero-name{display:grid;grid-template-columns:3fr 1fr;align-items:center;gap:64px;padding:32px 0 40px;border-bottom:2px solid}.hero-name h1{font-size:clamp(120px,23vw,368px);line-height:.85;letter-spacing:-.035em}.pixel-symbol{max-width:240px;justify-self:end;width:100%;padding-top:24px}.pixel-symbol>span{display:block;font-size:9px;margin-top:24px;text-align:center}.hero-bottom{display:grid;grid-template-columns:3fr 1fr;gap:64px;padding:40px 0 32px}.hero-bottom h2{font-size:clamp(34px,4.65vw,76px);line-height:1.04}.hero-side{display:flex;flex-direction:column;justify-content:space-between;font-size:12px;line-height:1.6}.hero-side .arrow-link{margin-top:24px}.hero-foot{display:flex;justify-content:space-between;align-items:center;border-top:1px solid;padding:16px 0 24px;font-size:10px}.barcode{font-size:24px;letter-spacing:4px}.investment{margin:48px calc(-1 * var(--gutter)) 0;padding:0 var(--gutter) 64px;background:var(--ink);color:var(--yellow)}.investment h2{padding:48px 0 0}.lead{font-size:clamp(32px,4vw,64px);display:block}.kinetic-word{display:block;font-size:clamp(100px,21vw,340px);line-height:.95;letter-spacing:-.04em;transform-origin:left center}.tail{display:block;text-align:right;font-size:clamp(32px,4vw,64px);margin-top:24px}.ascii-note{display:grid;grid-template-columns:1fr 1fr;gap:32px;align-items:end;margin-top:48px;padding-top:32px;border-top:1px solid}.ascii-note pre{margin:0;font-size:12px;line-height:1.1}.ascii-note p{font-size:14px;line-height:1.65}.quality{padding-top:48px}.section-meta h2{font:inherit}.type-row{display:grid;grid-template-columns:1fr 2fr 8fr 1fr;gap:16px;align-items:center;border-bottom:1px solid;padding:16px 0}.row-code{font-size:11px}.row-label{font-size:12px}.row-word{font-size:clamp(96px,13vw,208px);line-height:1}.row-end{font-size:48px;justify-self:end}.work-index{margin-top:80px}.index-row{display:grid;grid-template-columns:1fr 6fr 4fr 1fr;gap:16px;align-items:center;text-decoration:none;border-bottom:1px solid;padding:32px 0;font-size:12px}.index-row h3{font-size:clamp(24px,3vw,48px);font-weight:700;letter-spacing:-.06em}.index-row>:last-child{justify-self:end;font-size:24px}.index-row:hover{background:var(--ink);color:var(--yellow)}.invitation{padding:64px 0}.invitation h2{padding-top:48px}.invitation h2>.display{font-size:clamp(40px,5vw,80px);display:block}.invitation .blackletter{display:block;font-size:clamp(110px,20vw,320px);line-height:1}.invitation .arrow-link{margin-left:50%;margin-top:32px}
:global(.motion) .hero-name .period{animation:pixel-enter .6s steps(3,end) 1 both}:global(.motion) .kinetic-word:global(.in-view){animation:word-enter .65s steps(5,end) 1}:global(.motion) .type-row:global(.in-view) .row-word{animation:word-enter .5s steps(4,end) 1}:global(.motion) .type-row:hover .row-word{transform:translateX(8px)}:global(.motion) .pixel-symbol:hover{transform:translate(-8px,8px)}@keyframes word-enter{from{transform:translateX(-24px);clip-path:inset(0 100% 0 0)}to{transform:none;clip-path:inset(0)}}@keyframes pixel-enter{from{opacity:0;transform:translateY(-16px)}to{opacity:1;transform:none}}
@media(max-width:700px){.hero-name{gap:16px;padding:32px 0;grid-template-columns:1fr 72px}.hero-name h1{font-size:clamp(88px,23vw,160px)}.pixel-symbol{padding:0}.pixel-symbol>span{display:none}.hero-bottom{grid-template-columns:1fr;gap:24px;padding:32px 0}.hero-bottom h2{font-size:clamp(25px,6.3vw,43px)}.hero-side{display:grid;grid-template-columns:1fr 1fr;gap:16px;font-size:10px}.hero-side .arrow-link{margin:0;align-self:end;font-size:10px;padding:16px 0}.hero-foot{font-size:8px;gap:8px}.barcode{font-size:14px;letter-spacing:1px}.hero-foot>span:last-child{display:none}.investment{margin-top:24px;padding-bottom:40px}.investment h2{padding-top:32px}.lead,.tail{font-size:32px}.kinetic-word{font-size:clamp(94px,25vw,180px)}.tail{font-size:25px}.ascii-note{gap:24px;margin-top:32px;padding-top:24px;grid-template-columns:1fr 1.3fr}.ascii-note pre{font-size:9px}.ascii-note p{font-size:10px}.section-meta>span:last-child{font-size:8px}.type-row{grid-template-columns:24px 56px 1fr 20px;gap:8px}.row-code{font-size:8px}.row-label{font-size:9px}.row-word{font-size:clamp(72px,19vw,130px)}.row-end{font-size:24px}.work-index{margin-top:48px}.index-row{grid-template-columns:24px 1fr 24px;gap:8px;padding:24px 0;font-size:10px}.index-row .scope{display:none}.index-row h3{font-size:28px}.invitation{padding:40px 0}.invitation h2{padding-top:32px}.invitation h2>.display{font-size:36px}.invitation .blackletter{font-size:clamp(92px,26vw,170px)}.invitation .arrow-link{margin-left:0;margin-top:24px}}
</style>
