<script lang="ts">
  const projects = [
    { title: 'Pocketwatch', slug: 'pocketwatch', scope: 'Brand, product & front end', year: '2026', description: 'Brand identity, design system, and front-end for an all-in-one personal finance app: budgeting, net worth, and investments in one clean view.', alt: 'Pocketwatch campaign: budgeting and investing in one place, on electric lime' },
    { title: 'PARC', slug: 'parc', scope: 'Cofounder · Brand & art direction', year: '2021–2026', description: 'Rebranding the NFT club I cofounded in 2021: logo, palette, pixel world, and a typeface, all from one 5×5 grid.', alt: 'PARC’s four-color pixel letters on a white sign floating in a pixel-cloud sky' },
    { title: 'xrp.cafe', slug: 'xrpcafe', scope: 'Cofounder · Brand & motion', year: '2021–2024', description: 'Visual identity, motion design, and marketing for an NFT marketplace on the XRP Ledger.', alt: 'xrp.cafe coffee-mug logo lockup' },
    { title: 'First Ledger', slug: 'firstledger', scope: 'Senior brand designer', year: '2024–2025', description: 'Complete visual identity system for a token trading platform on the XRP Ledger.', alt: 'First Ledger billboard mockup: The fastest way to trade' }
  ];
</script>
<svelte:head><title>Selected work — Timothy Ali</title><meta name="description" content="Selected brand, product, motion, and front-end work by designer Timothy Ali." /></svelte:head>
<main class="inner-page" id="main" tabindex="-1">
  <div class="section-meta"><span>02 / SELECTED OUTPUT</span><span>BRAND / PRODUCT / MOTION / CODE</span></div>
  <h1 class="page-heading display">Selected<br /><span class="blackletter">work.</span></h1>
  <div class="work-list">
    {#each projects as project, index}
      <article id={project.slug}>
        <div class="project-copy"><div class="project-meta"><span>[{String(index + 1).padStart(2, '0')}]</span><span>{project.year}</span></div><h2>{project.title}</h2><p class="scope">{project.scope}</p><p class="project-description">{project.description}</p><a class="arrow-link" href={`https://timothyali.com/work/${project.slug}`}>View case study <span aria-hidden="true">↗</span></a></div>
        <a class="project-image" href={`https://timothyali.com/work/${project.slug}`} aria-label={`View ${project.title} case study`}><img src={`/work/${project.slug}.${project.slug === 'firstledger' ? 'jpg' : 'png'}`} alt={project.alt} loading={index === 0 ? 'eager' : 'lazy'} width="1600" height="900" /><span class="image-label" aria-hidden="true">OPEN PROJECT ↗</span></a>
      </article>
    {/each}
  </div>
  <footer class="page-footer"><span>END OF INDEX / 004</span><a href="/contact/">Tell me what you’re building ↗</a></footer>
</main>
<style>
  article{display:grid;grid-template-columns:1fr 2fr;gap:64px;padding:40px 0;border-top:2px solid;scroll-margin-top:24px}.project-copy{display:flex;flex-direction:column;min-width:0}.project-meta{display:flex;justify-content:space-between;font-size:11px;margin-bottom:32px}h2{font-size:clamp(32px,3.5vw,56px);letter-spacing:-.06em;font-weight:700}.scope{font-size:10px;text-transform:uppercase;margin-top:16px}.project-description{font-size:13px;line-height:1.65;margin:32px 0}.project-copy .arrow-link{margin-top:auto;font-size:11px}.project-image{position:relative;display:block;align-self:start;background:var(--ink)}.project-image img{display:block;width:100%;height:auto;aspect-ratio:16/9;object-fit:contain}.image-label{position:absolute;right:0;bottom:0;background:var(--yellow);padding:16px;font-size:10px}.project-image:hover .image-label{background:var(--ink);color:var(--yellow)}
  @media(max-width:700px){article{grid-template-columns:1fr;gap:24px;padding:24px 0 40px}.project-meta{margin-bottom:24px}.project-description{margin:24px 0}.project-image{grid-row:2}.image-label{padding:12px}.scope{margin-top:12px}}
</style>
