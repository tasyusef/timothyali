<script lang="ts">import PixelMark from '$lib/components/PixelMark.svelte';</script>
<svelte:head><title>Get in touch — Timothy Ali</title><meta name="description" content="Tell me what you’re building. Connect with designer Timothy Ali about brand, product, motion, and front-end work." /></svelte:head>
<main class="inner-page" id="main" tabindex="-1">
  <div class="section-meta"><span>03 / START A CONVERSATION</span><span>HUMAN TO HUMAN.</span></div>
  <div class="contact-heading"><h1><span class="display">Tell me what<br />you’re</span><span class="blackletter">building.</span></h1><div class="mark"><PixelMark /></div></div>
  <div class="contact-detail"><p>Got an idea, an early team, or something that needs a designer?<br /><br />I’d like to hear about it.</p><a class="arrow-link" href="https://linkedin.com/in/timothyali">Message me on LinkedIn <span aria-hidden="true">↗</span></a></div>
  <footer class="page-footer"><span>BRAND / PRODUCT / MOTION / FRONT END</span><a href="/work/">See my work ↗</a></footer>
</main>
<style>
.contact-heading{display:grid;grid-template-columns:3fr 1fr;gap:64px;align-items:end;margin:64px 0 48px}.display{font-size:clamp(40px,6vw,96px);display:block}.blackletter{display:block;font-size:clamp(110px,18vw,280px);line-height:1}.mark{padding-bottom:24px}.contact-detail{display:grid;grid-template-columns:1fr 1fr;gap:64px;border-top:2px solid;padding-top:32px}.contact-detail p{font-size:16px;line-height:1.6;max-width:40ch}.contact-detail .arrow-link{align-self:end;font-size:13px}.page-footer{margin-top:80px}@media(max-width:700px){.contact-heading{grid-template-columns:1fr;gap:24px;margin:40px 0}.display{font-size:40px}.blackletter{font-size:clamp(94px,26vw,170px)}.mark{width:64px;padding:0;justify-self:end}.contact-detail{grid-template-columns:1fr;gap:24px;padding-top:24px}.contact-detail p{font-size:13px}.contact-detail .arrow-link{font-size:11px}.page-footer{margin-top:48px}}
</style>
