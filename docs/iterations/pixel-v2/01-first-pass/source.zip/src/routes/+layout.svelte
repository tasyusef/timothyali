<script lang="ts">
  import '@fontsource/jacquard-24/400.css';
  import '../app.css';
  import { page } from '$app/state';
  import { onMount } from 'svelte';
  let { children } = $props();
  let reduced = $state(true);
  let mounted = $state(false);
  let explicit = false;
  function setMotion(){ reduced = !reduced; explicit = true; try {localStorage.setItem('tim-motion', reduced ? 'off' : 'on')} catch {} }
  onMount(()=>{
    mounted=true;
    const media=matchMedia('(prefers-reduced-motion: reduce)');
    let saved=null;try{saved=localStorage.getItem('tim-motion')}catch{}
    explicit=saved==='on'||saved==='off'; reduced=explicit ? saved==='off' : media.matches;
    const update=()=>{if(!explicit)reduced=media.matches};media.addEventListener('change',update);
    return ()=>media.removeEventListener('change',update);
  });
</script>
<div class="site" class:motion={!reduced} data-motion={reduced ? 'off' : 'on'}>
  <a class="skip-link" href="#main">Skip to content</a>
  <header class="site-header">
    <a class="wordmark" href="/" aria-label="Timothy Ali — home">Timothy Ali</a>
    <span class="header-note">DESIGN + BUILD<br />DENVER, CO</span>
    <nav aria-label="Main navigation">
      <a href="/" aria-current={page.url.pathname==='/'?'page':undefined}><span>01</span> Index</a>
      <a href="/work/" aria-current={page.url.pathname.startsWith('/work')?'page':undefined}><span>02</span> Work</a>
      <a href="/contact/" aria-current={page.url.pathname.startsWith('/contact')?'page':undefined}><span>03</span> Contact</a>
    </nav>
  </header>
  {@render children()}
  <footer class="global-footer"><span>© {new Date().getFullYear()} TIMOTHY ALI</span><span class="footer-note">A LITTLE HUMAN. A LITTLE MACHINE.</span>{#if mounted}<button type="button" onclick={setMotion} aria-label={reduced?'Turn motion on':'Turn motion off'}>MOTION [{reduced?'OFF':'ON'}]</button>{/if}</footer>
</div>
