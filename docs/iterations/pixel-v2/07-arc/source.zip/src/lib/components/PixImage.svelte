<script lang="ts">
  // A photograph resampled to one colour per 2px site-grid cell. The original
  // <img> stays in the document for alt text and as the no-JavaScript rendering.
  import { onMount } from 'svelte';
  import { theme } from '$lib/motion.svelte';
  let { src, alt, cell = 2, width = 1600, height = 900, eager = false }: { src: string; alt: string; cell?: number; width?: number; height?: number; eager?: boolean } = $props();
  let img: HTMLImageElement; let canvas: HTMLCanvasElement; let host: HTMLElement;
  let ready = $state(false);
  function render() {
    if (!img.complete || !img.naturalWidth) return;
    const r = host.getBoundingClientRect(); if (!r.width) return;
    const dpr = Math.max(1, Math.min(3, Math.round(window.devicePixelRatio || 1)));
    const cellPx = cell;
    const cols = Math.floor(r.width / cellPx), rows = Math.floor((r.width * (height / width)) / cellPx);
    host.style.height = rows * cellPx + 'px';
    snap(cellPx);
    const off = document.createElement('canvas'); off.width = cols; off.height = rows;
    const o = off.getContext('2d'); if (!o) return;
    o.fillStyle = getComputedStyle(host).backgroundColor; o.fillRect(0, 0, cols, rows);
    // letterbox into the cell grid
    const scale = Math.min(cols / img.naturalWidth, rows / img.naturalHeight);
    const w = Math.round(img.naturalWidth * scale), h = Math.round(img.naturalHeight * scale);
    o.drawImage(img, Math.floor((cols - w) / 2), Math.floor((rows - h) / 2), w, h);
    canvas.width = cols * cellPx * dpr; canvas.height = rows * cellPx * dpr; canvas.style.width = cols * cellPx + 'px'; canvas.style.height = rows * cellPx + 'px';
    const c = canvas.getContext('2d'); if (!c) return;
    // full colour, one sample per cell: the photograph sits on the same grid as the type
    c.imageSmoothingEnabled = false;
    c.drawImage(off, 0, 0, canvas.width, canvas.height);
    ready = true;
  }
  // Snap the canvas origin to the page grid; the image shifts by under one cell.
  // Re-run whenever the document reflows, since the figure's page position can move.
  function snap(cellPx = cell) {
    const r = host.getBoundingClientRect();
    const pageX = r.left + window.scrollX, pageY = r.top + window.scrollY;
    const offX = ((pageX % cellPx) + cellPx) % cellPx, offY = ((pageY % cellPx) + cellPx) % cellPx;
    canvas.style.left = -offX + 'px'; canvas.style.top = -offY + 'px';
  }
  $effect(() => { void theme.light; if (img?.complete) render(); });
  onMount(() => {
    const ro = new ResizeObserver(render); ro.observe(host);
    const body = new ResizeObserver(() => snap()); body.observe(document.body);
    if (img.complete) render();
    return () => { ro.disconnect(); body.disconnect(); };
  });
</script>
<figure class="pix" bind:this={host} class:ready>
  <img bind:this={img} {src} {alt} {width} {height} loading={eager ? 'eager' : 'lazy'} decoding="async" onload={render} />
  <canvas bind:this={canvas} aria-hidden="true"></canvas>
</figure>
<style>
.pix{position:relative;margin:0;width:100%;aspect-ratio:16/9;overflow:hidden;background:var(--paper);color:var(--fg)}
img{display:block;width:100%;height:100%;object-fit:contain;image-rendering:pixelated}
canvas{position:absolute;left:0;top:0;display:none;image-rendering:pixelated}
.ready img{opacity:0}.ready canvas{display:block}
</style>
