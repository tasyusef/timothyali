import { error } from '@sveltejs/kit';
import { projects } from '$lib/work';
import type { PageLoad, EntryGenerator } from './$types';

export const entries: EntryGenerator = () => projects.map((p) => ({ slug: p.slug }));

export const load: PageLoad = ({ params }) => {
  const i = projects.findIndex((p) => p.slug === params.slug);
  if (i < 0) error(404, 'No such project');
  return { project: projects[i], next: projects[(i + 1) % projects.length] };
};
