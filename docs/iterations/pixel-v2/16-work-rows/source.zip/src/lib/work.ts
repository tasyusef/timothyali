// The work index and the four case studies (Pocketwatch replaced by Do Androids Dream on Timothy's instruction, 2026-09-09). One source for Home, Work and /work/<slug>/.
// Images live in static/work/<slug>/ at 1600px on the long side (plus `@2x.jpg` at 2800px where
// the source allowed); `w`/`h` are the 1x file's pixel dimensions so every figure holds its aspect.

export interface Media { src: string; w: number; h: number; alt: string; video?: boolean; x2?: string }
export type Row = Media[];
export type Block =
  | { type: 'text'; title: string; paras: string[] }
  | { type: 'gallery'; rows: Row[]; note?: string }
  | { type: 'list'; title: string; items: string[] };

export interface Project {
  n: string;
  slug: string;
  title: string;
  /** the blackletter title, lowercase like every other emphasis word on the site */
  word: string;
  year: string;
  scope: string;
  role: string;
  timeline?: string;
  tools: string;
  live?: { href: string; label: string };
  /** index line on Home and Work */
  description: string;
  cover: Media;
  lead: string[];
  hero: Row;
  blocks: Block[];
}

// files that also exist as `<name>@2x.jpg` (2800px on the long side) for dense screens
const X2 = new Set(['firstledger/guide-01', 'firstledger/guide-02', 'firstledger/guide-03', 'firstledger/guide-04', 'firstledger/guide-05', 'firstledger/guide-07', 'firstledger/guide-08', 'firstledger/guide-10', 'firstledger/hero', 'parc/club-masthead-sky', 'parc/phone-arcade', 'parc/phone-hero', 'parc/sign-sky', 'parc/site-arcade', 'parc/site-bands', 'parc/site-collections', 'parc/site-crew', 'parc/site-hero', 'xrpcafe/backdrop', 'xrpcafe/banner', 'xrpcafe/booth-setup', 'xrpcafe/booth-table', 'xrpcafe/booth-tablet', 'xrpcafe/booth-team', 'xrpcafe/jeopardy', 'xrpcafe/just-mint', 'xrpcafe/logo', 'xrpcafe/marketplace', 'xrpcafe/mug-bbq', 'xrpcafe/mug-pumpkin', 'xrpcafe/mug-saiyan', 'xrpcafe/vesea-charity', 'xrpcafe/xrpl-group']);
const media = (slug: string) => (f: string, w: number, h: number, alt: string): Media => {
  const base = f.replace(/\.[a-z]+$/, '');
  return { src: `/work/${slug}/${f}`, w, h, alt, x2: X2.has(`${slug}/${base}`) ? `/work/${slug}/${base}@2x.jpg` : undefined };
};
const pa = media('parc'), xc = media('xrpcafe'), fl = media('firstledger'), dad = media('do-androids-dream');

export const projects: Project[] = [
  {
    n: '01',
    slug: 'parc',
    title: 'PARC',
    word: 'parc',
    year: '2021–2026',
    scope: 'Cofounder · brand & art direction',
    role: 'Cofounder · brand & art direction',
    timeline: 'Ongoing',
    tools: 'Illustrator, Python (fontTools)',
    live: { href: 'https://parcxrpl.com', label: 'parcxrpl.com' },
    description: 'Rebranding the NFT club I cofounded in 2021: logo, palette, pixel world, and a typeface, all from one 5×5 grid.',
    cover: { src: '/work/parc.png', w: 1600, h: 900, alt: 'PARC’s four-color pixel letters on a white sign floating in a pixel-cloud sky' },
    lead: [
      'Pixel Ape Rowboat Club started in November 2021 as a joke. People were treating pixel apes as status symbols, and we thought that was ridiculous. Bored Apes had yachts. Ours had rowboats. 10,000 pixel apes on the XRP Ledger, no clout included.',
      'People stayed anyway. Four years later PARC is four collections, a Twitch show, an arcade, merch, its own lore, and about 196,000 XRP traded. I cofounded it with xrpl_adam on the build, sloppy on marketing, and stove drawing the apes with me. Branding and art direction have been mine throughout. The 2026 rebrand is the brand catching up to the community, the world, and the story.'
    ],
    hero: [pa('sign-sky.png', 1600, 900, 'The new PARC box logo: four-color pixel letters on a white sign with notched corners, floating in a pixel-cloud sky')],
    blocks: [
      { type: 'text', title: 'The world', paras: [
        'The apes were retro from day one. The reference was the Game Boy Advance Pokémon games: the pixel size, the flat color, a sprite that reads at a glance. The world grew from there: islands, rowboats, volcanoes, wooden huts, tropical and unserious. That world is what the community actually cares about, and it is what the rebrand had to serve.'
      ] },
      { type: 'text', title: 'Same people, better brand', paras: [
        'The art was always retro. The logo never was: a cartoon ape with thick outlines and a bubbly wordmark, fine on its own and from a different product. In 2026 it was time. The new logo is drawn on the same 5×5 grid as the apes, on a white sign with notched corners.',
        'The hard part wasn’t drawing it. The team was attached to the old brand and worried people would hate a change, which is what people do with rebrands at first. I asked them to trust that this is what I do for a living. It shipped, and the response was the opposite of what they feared.'
      ] },
      { type: 'gallery', note: 'Before, 2021 / after, 2026', rows: [
        [pa('old-mascot.png', 1600, 1600, 'The old PARC logo: a cartoon ape head with a wide grin and thick black outlines, a bubbly yellow PARC wordmark across the top'), pa('old-wordmark.png', 1600, 900, 'The old PARC secondary logo: the bubbly outlined wordmark in black')],
        [pa('mark-stacked.png', 1600, 1600, 'The new PARC square lockup: the box logo stacked over the oar'), pa('twitter-banner.png', 1600, 533, 'PARC X header: the box logo on the pixel-cloud sky')]
      ] },
      { type: 'list', title: 'The reaction', items: [
        '“I know I like the new banner and logo” — RedHotDankMoist, Discord',
        '“@twocakeS these graphics is gas” — DreamballerXRP, Discord',
        '“Love it, great website update, looks amazing” — @BrandoWoodz, X',
        '“loOkn goOd” — @Uga589, X'
      ] },
      { type: 'text', title: 'The system', paras: [
        'Three marks, one construction: the box logo wide and square, and the oar badge. Same cell grid, same notched corners. The masters are merged paths, never loose squares. Clear space is two cells on every side.',
        'Five colors, no tints, no gradients. Each element gets one of them; the four-color cycling stays in the logo. Yellow never sets type on white. Web uses the hex values, print the CMYK builds.',
        'The secondary mark is one horizontal oar: the favicon, the badge, and the equals key in the fonts, so it drops into any line of pixel type as a divider.'
      ] },
      { type: 'text', title: 'The typeface', paras: [
        'PARC Pixel was the first thing made after the logo. The four letters became the style guide for an alphabet: one-cell strokes, hollow counters, stepped diagonals, every letter five cells wide. Three weights, each in square pixels, plus a mono cut for scores and prices. Twenty-nine glyphs were finished by hand, the 2 and the at-sign among them, judged in real words at reading size. The oar lives on the equals key.'
      ] },
      { type: 'gallery', rows: [
        [pa('club-masthead-sky.png', 1600, 900, 'PARC Pixel specimen on the sky colorway: Pixel Ape Rowboat Club set across the three weights')],
        [pa('three-weights-a.png', 1600, 1200, 'PARC Pixel specimen on white: the letter A in Bold 700, Regular 400, and Light 300'), pa('anatomy-sheet.png', 1600, 1200, 'PARC Pixel specimen on white: the Bold R on its 11 by 11 cell grid'), pa('mono-numerals-sky.png', 1600, 1200, 'PARC Pixel Mono numerals 0 to 9 on the sky colorway')],
        [pa('glyph-grid-green.png', 1600, 1200, 'PARC Pixel Bold: 40 glyphs in a grid, one color per glyph, on the green colorway'), pa('square-ampersand-sky.png', 1600, 1600, 'PARC Pixel Bold ampersand at giant size on the sky colorway')]
      ] },
      { type: 'text', title: 'In the wild', paras: [
        'Everything PARC puts out now runs on the system: the site, Discord, X, the Twitch show every other Friday, merch, and the arcade. The site is the main event. The hero sign hangs in the sky, the collections float on the island, the arcade band is the game’s own island with live high scores, and After Darc and Discord get their own bands. The stream opens on its own starting-soon loop.',
        'Plain type carried the specimens, but a graphic needs more than a layout grid to look alive. So every surface got a generated background: clouds drifting in hard steps, the hero scatter that twinkles and sparks under the cursor, CRT static for After Darc, chat bubbles for Discord. They add some life, nothing more. Reduced motion gets the still versions.'
      ] },
      { type: 'gallery', rows: [
        [pa('site-hero.png', 1600, 1000, 'parcxrpl.com hero: Pixel Ape Rowboat Club on the notched sign over the scatter texture, with the green nav bar')],
        [pa('site-collections.png', 1600, 1000, 'parcxrpl.com collections: PARC, Monkey Phunks, and PARC Customs cards floating on the pixel-cloud sky'), pa('phone-hero.png', 739, 1600, 'parcxrpl.com hero on a phone')],
        [pa('site-arcade.jpg', 1600, 1000, 'parcxrpl.com arcade band: the Rowboat Racer cover on a CRT and live high scores over the island'), pa('site-bands.png', 1600, 1000, 'parcxrpl.com After Darc band in Twitch purple and Discord band in blurple')],
        [pa('site-crew.png', 1600, 1000, 'parcxrpl.com crew row and green footer with the stacked mark'), pa('phone-arcade.jpg', 739, 1600, 'parcxrpl.com arcade band on a phone: the Rowboat Racer cover over the island')],
        [{ src: '/work/video/parc-after-darc-intro.mp4', w: 1920, h: 1080, video: true, alt: 'PARC After Darc starting-soon screen: a pixel sun over the sea with a rowboat drifting past, looped before the stream' }],
        [pa('after-darc-announce.png', 1600, 1600, 'PARC After Darc new-stream graphic: the wordmark over a pixel sunset, Saturday 9pm UTC on Twitch'), pa('after-darc-live.png', 1600, 1600, 'PARC After Darc live-now graphic: the wordmark over a pixel night sky and moon'), pa('after-darc-today.png', 1600, 1600, 'PARC After Darc tonight graphic'), pa('after-darc-reminder.png', 1600, 1600, 'PARC After Darc tomorrow graphic')],
        [pa('larc-teaser.jpg', 1600, 1600, 'LARC teaser: glitched terminal text on black announcing the next collection'), pa('parcade-scores.jpg', 1600, 1600, 'PARCade high-score board in PARC Pixel Mono')]
      ] },
      { type: 'list', title: 'Outcome', items: [
        'One logo library for both lockups and the oar: black, CMYK, Pantone, and white for print; black, RGB, and white for web.',
        'Five colors and one typeface on every surface: site, Discord, X, Twitch, merch, and the arcade.',
        'PARC Pixel: 57 characters per weight, three weights, proportional and mono.',
        'Four generated backgrounds, one per band of the site, and the game island drawn from its own sprites.',
        'Live since September 2026, to a community that is active and growing.'
      ] }
    ]
  },
  {
    n: '02',
    slug: 'xrpcafe',
    title: 'xrp.cafe',
    word: 'xrp.cafe',
    year: '2021–2024',
    scope: 'Cofounder · brand & motion',
    role: 'Cofounder & founding designer',
    tools: 'Illustrator, After Effects',
    live: { href: 'https://xrp.cafe/', label: 'xrp.cafe' },
    description: 'Visual identity, motion design, and marketing for an NFT marketplace on the XRP Ledger.',
    cover: { src: '/work/xrpcafe.png', w: 1600, h: 900, alt: 'xrp.cafe coffee-mug logo lockup' },
    lead: [
      'xrp.cafe is the #1 NFT marketplace on the XRP Ledger. As cofounder and founding designer, I built the brand from nothing and led its rollout across marketing, events, and content: 10+ social campaigns, motion graphics, event booths, and community touchpoints.',
      'The positioning ran against the whole field. Crypto branding in 2021 was dark, aggressive, and self-serious. We went warm, friendly, and approachable: a cozy place for NFTs. That warmth set us apart and kept people with us.'
    ],
    hero: [
      { src: '/work/video/xrpcafe-explore-create-trade.mp4', w: 1080, h: 1920, video: true, alt: 'xrp.cafe Explore Create Trade motion graphic' },
      xc('logo.png', 1600, 900, 'xrp.cafe coffee-mug logo lockup on the brand blue')
    ],
    blocks: [
      { type: 'text', title: 'The mascot system', paras: [
        'The brand centers on its mascot: a simple, expressive coffee mug with stick-figure limbs and a warm smile. It began as a logo mark and grew into a full cast of characters, each with its own personality and accessories, that fronted the brand on every touchpoint.',
        'A mascot system works when it can vary without drifting. I drew new characters and scenes for campaigns, seasonal moments, and community milestones: a Halloween pumpkin mug, a beach-BBQ mug, a Super Saiyan mug. Each read as xrp.cafe at a glance, and none needed a brand guideline to feel right.'
      ] },
      { type: 'gallery', rows: [
        [xc('mug-saiyan.png', 1600, 900, 'xrp.cafe Super Saiyan mug mascot character'), xc('mug-bbq.png', 1600, 900, 'xrp.cafe beach-BBQ mug mascot character'), xc('mug-pumpkin.png', 1600, 900, 'xrp.cafe Halloween pumpkin mug mascot')],
        [xc('marketplace.png', 1600, 900, 'xrp.cafe marketplace UI with mascot characters')]
      ] },
      { type: 'text', title: 'Motion graphics', paras: [
        'The “Explore, Create, Trade” promo compresses the whole pitch into one fast animated piece: kinetic typography, smooth character animation, and the brand’s signature blue throughout. I made it for the feed, not the film festival: vertical format, legible on a phone mid-scroll, message delivered in seconds.',
        'Around the hero promo I built a library of motion assets for product launches, feature announcements, and event recaps, which gave the brand a steady, energetic presence in feeds. Each piece had one job: show one platform feature, fast, in character.'
      ] },
      { type: 'text', title: 'Community as a channel', paras: [
        'An NFT marketplace depends on its community, so the brand’s main medium was the daily feed. I produced a steady stream of content for Twitter/X, Instagram, and Discord: product announcements, feature launches, community events, seasonal posts, partnerships, milestone celebrations. The pace never let up: several posts a week, each needing custom graphics, copy, and a read on what the community cared about that day.',
        'The same system carried into the physical world, with booth designs, backdrops, banners, and merch for Consensus, Permissionless, and ETH Denver. On a conference floor full of black-and-neon, a warm, recognizable brand stood out.'
      ] },
      { type: 'gallery', rows: [
        [xc('just-mint.png', 1600, 900, 'xrp.cafe JUST MINT NFTs campaign graphic'), xc('jeopardy.png', 1600, 900, 'xrp.cafe community Jeopardy event graphic'), xc('vesea-charity.png', 1600, 900, 'xrp.cafe and VeSea charity event graphic')],
        [xc('xls20.png', 1600, 1600, 'xrp.cafe XLS-20 one year anniversary artwork'), xc('booth-team.jpg', 1200, 1600, 'xrp.cafe team at the Consensus booth'), xc('xrpl-group.jpg', 1600, 1600, 'XRP Ledger community group photo at Consensus')],
        [xc('booth-setup.jpg', 1600, 1200, 'xrp.cafe booth setup at Permissionless'), xc('booth-table.jpg', 1200, 1600, 'xrp.cafe booth table with stickers and merch'), xc('booth-tablet.jpg', 1200, 1600, 'xrp.cafe website demo at Consensus 2023')],
        [xc('backdrop.jpg', 1600, 1200, 'xrp.cafe event backdrop mockup'), xc('banner.jpg', 1600, 1200, 'xrp.cafe retractable banner mockups')]
      ] },
      { type: 'list', title: 'Outcome', items: [
        '#1 NFT marketplace on the XRP Ledger by secondary sales volume.',
        '$5M+ in marketplace revenue.',
        'Community grown to 32,000+ members.',
        '11,800+ secondary sales in a single 30-day period at peak (Nov 2023).',
        'Helped raise $32K for St. Jude’s with VeSea.',
        'Profiled by Messari as one of the most established touchpoints on XRPL, featured on the official XRPL developer blog, and backed by the XRPL Accelerator.',
        'Booth and brand presence at Consensus (2023, 2024), Permissionless 2024 in the Ripple X section, and ETH Denver (2022–2024).'
      ] }
    ]
  },
  {
    n: '03',
    slug: 'firstledger',
    title: 'First Ledger',
    word: 'first ledger',
    year: '2024–2025',
    scope: 'Senior brand designer',
    role: 'Senior brand designer',
    timeline: 'About a year',
    tools: 'Illustrator',
    live: { href: 'https://firstledger.net/', label: 'firstledger.net' },
    description: 'Complete visual identity system for a token trading platform on the XRP Ledger.',
    cover: { src: '/work/firstledger.jpg', w: 1600, h: 900, alt: 'First Ledger billboard mockup: The fastest way to trade' },
    lead: [
      'First Ledger is a token trading platform on the XRP Ledger: a Telegram bot and a full web interface at firstledger.net for fast, self-custody access to the XRPL’s native DEX and AMM pools. The team behind xrp.cafe built it, and it has grown into one of the top DEX gateways on the network by trading volume.',
      'I designed the complete visual identity over a year-long engagement, from logo concept through full brand guidelines with co-branding rules: a system built to grow with the product.'
    ],
    hero: [fl('hero.jpg', 1600, 1200, 'First Ledger billboard mockup: The fastest way to trade')],
    blocks: [
      { type: 'text', title: 'Pencil + paper = ledger', paras: [
        'Two elemental shapes make the mark. A diagonal form is the pencil: the act of recording. A rounded square is the paper: the surface that holds the record. Together they read as a single icon: a ledger, a record of transactions.',
        'Two shapes, one idea, no decoration. The mark survives any scale, 16px favicon to billboard, because there’s nothing extra to lose at small sizes. For a product that lives in Telegram chats, a web trading interface, and small mobile screens, that scalability was the core requirement. I designed the whole identity around it.'
      ] },
      { type: 'gallery', rows: [
        [fl('guide-01.png', 1600, 900, 'First Ledger logo white on black'), fl('guide-04.png', 1600, 900, 'First Ledger logo construction: Pencil + Paper = Ledger diagram')]
      ] },
      { type: 'text', title: 'Lockups & typography', paras: [
        'The primary lockup pairs the icon with “FIRST LEDGER” in a heavy extended grotesque; the secondary shortens it to “FL” for compact contexts. Both carry clear-space rules measured in multiples of the icon’s own width, so spacing never depends on anyone’s eye.',
        'I chose extended letterforms to counter the condensed, aggressive type that dominates crypto. Width signals confidence and stability, and both matter when you ask people to route real money through your platform. The type system runs three weights of the same extended family: Heavy for headlines, Medium for subheads, Roman for body.'
      ] },
      { type: 'gallery', rows: [
        [fl('guide-03.png', 1600, 900, 'First Ledger primary and secondary logo lockups'), fl('guide-05.png', 1600, 900, 'First Ledger primary logo clear-space rules')],
        [fl('guide-10.png', 1600, 900, 'First Ledger typography system spread')]
      ] },
      { type: 'text', title: 'Brand pillars', paras: [
        'Fun: “a lil meme never hurt anyone.” Reliable: “passion and years of experience.” Fast: “we’re first for a reason.”',
        'Those three words governed every visual call. The playful register kept the brand human in a field of self-serious competitors. The stress on speed and reliability let the same identity work in professional contexts, exchange listings, partnership decks, ecosystem reports, without a redesign.'
      ] },
      { type: 'text', title: 'Co-branding guidelines', paras: [
        'First Ledger shares an ecosystem (and a team) with xrp.cafe, so the guidelines set exact co-branding rules: spacing for how the two logos sit together. With the rules written in advance, every collaboration looks planned, not improvised.',
        'As the platform grew into partnerships and integrations, those rules got the heaviest use. They kept the brand consistent across CoinGecko listings, DappRadar profiles, Messari reports, and co-marketing with other XRPL projects.'
      ] },
      { type: 'gallery', rows: [
        [fl('guide-02.png', 1600, 900, 'First Ledger brand pillars: Fun, Reliable, Fast')],
        [fl('guide-07.png', 1600, 900, 'First Ledger and xrp.cafe co-branding guidelines, primary lockup'), fl('guide-08.png', 1600, 900, 'First Ledger and xrp.cafe co-branding guidelines, secondary lockup')]
      ] },
      { type: 'list', title: 'Outcome', items: [
        'The identity held unchanged across every exchange listing, ecosystem report, and co-branded surface as the platform grew.',
        'First Telegram-based trading bot on the XRP Ledger.',
        'Consistently ranked top 2–3 DEX gateway on XRPL by trading volume (Messari).',
        'Ripple credited it with driving Q4 2024 XRPL growth: daily CLOB volume rose 1,140% quarter on quarter.',
        'Listed on CoinGecko, DappRadar, and GeckoTerminal as a tracked exchange.',
        'Featured in every Messari “State of XRP Ledger” report since Q2 2024.'
      ] }
    ]
  },
  {
    n: '04',
    slug: 'do-androids-dream',
    title: 'Do Androids Dream?',
    word: 'do androids dream?',
    year: '2023',
    scope: 'Motion & art direction',
    role: 'Director, designer, animator',
    tools: 'After Effects, Illustrator',
    description: 'A two-color title sequence for Philip K. Dick’s “Do Androids Dream of Electric Sheep?”: Saul Bass instead of Blade Runner.',
    cover: { src: '/work/do-androids-dream.jpg', w: 1600, h: 900, alt: 'Do Androids Dream title sequence: the sun with beams radiating out behind a lone figure, black on yellow' },
    lead: [
      'A title sequence for Philip K. Dick’s Do Androids Dream of Electric Sheep?, the novel that inspired Blade Runner. Everyone expects the dark, rain-soaked look. I went the other way: a stark, high-contrast yellow-and-black graphic style closer to Saul Bass than Ridley Scott.'
    ],
    hero: [{ src: '/work/video/do-androids-dream-title-sequence.mp4', w: 1280, h: 720, video: true, alt: 'Do Androids Dream title sequence, forty-five seconds, black on yellow' }],
    blocks: [
      { type: 'text', title: 'The concept', paras: [
        'What does this story look like with the atmosphere stripped away, cut down to its plainest graphic elements? That question drove every decision in the sequence.',
        'The answer was a two-color world: bright yellow and deep black, nothing else. The yellow is the artificial, the synthetic, the electric; the black is the void. Together they make a world at once stark and overwhelming, and the narrow palette forces the eye onto what’s left: shape, movement, composition.'
      ] },
      { type: 'gallery', rows: [
        [dad('hero.jpg', 1600, 900, 'Do Androids Dream title sequence: the sun with beams radiating out behind a lone figure, black on yellow')]
      ] },
      { type: 'text', title: 'Visual language', paras: [
        'The sequence centers on a dystopian skyline: a jagged silhouette of towers and industrial structures drawn as flat black vector shapes against the yellow sky. Against that mass stands a lone silhouetted figure, the emotional core of the piece: one person dwarfed by the built environment.',
        'Subtle chromatic aberration flickers at the edges of the vector shapes throughout: a hint of electronic interference that leaves the world slightly misaligned, as if seen through a synthetic lens. It’s the only effect in the piece, which is why it registers.'
      ] },
      { type: 'text', title: 'Motion & pacing', paras: [
        'Three acts in forty-five seconds. Act one: the title builds word by word on a flat yellow field. Act two: the cityscape enters and the credits play against it. Act three: the perspective breaks, and the camera pulls into the city along a converging road as the sun rises and beams radiate outward.',
        'The anti–Blade Runner look is itself the statement: source material this rich deserves more than one visual reading.'
      ] },
      { type: 'gallery', rows: [
        [dad('still-title.jpg', 1280, 720, 'Act one: the title in heavy black type on a flat yellow field'), dad('still-cityscape.jpg', 1280, 720, 'Act two: a black city skyline against yellow with a lone figure at right, edges fringed by chromatic aberration')],
        [dad('still-road.jpg', 1280, 720, 'Act three: the perspective breaks and a black road converges between yellow city blocks'), dad('still-sunrise.jpg', 1280, 720, 'Act three: a yellow sun rising into a black sky')]
      ] }
    ]
  }
];

/** grid-template-columns for a gallery row: widths proportional to aspect, snapped to the 2px image cell (galleries hold no text, so the 8px text grid does not apply), the last column taking the small remainder so every image in the row is within a few pixels of the same height */
export function rowColumns(row: Row, gap = 16): string {
  if (row.length === 1) return '100%';
  const aspects = row.map((m) => m.w / m.h);
  const total = aspects.reduce((a, b) => a + b, 0);
  const inner = `(100% - ${gap * (row.length - 1)}px)`;
  return aspects.slice(0, -1).map((a) => `round(nearest, calc(${inner} * ${(a / total).toFixed(6)}), 2px)`).join(' ') + ' 1fr';
}

/** index count as printed in the chrome, e.g. 004 */
export const count = String(projects.length).padStart(3, '0');
