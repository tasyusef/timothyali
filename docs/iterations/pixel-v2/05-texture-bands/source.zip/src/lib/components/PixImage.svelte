<script lang="ts">
  // Two-colour ordered dither of a photograph, drawn in 2px site-grid cells. The original
  // <img> stays in the document for alt text and as the no-JavaScript rendering.
  import { onMount } from 'svelte';
  import { BAYER8 } from '$lib/prng';
  let { src, alt, cell = 2, width = 1600, height = 900, eager = false }: { src: string; alt: string; cell?: number; width?: number; height?: number; eager?: boolean } = $props();
  let img: HTMLImageElement; let canvas: HTMLCanvasElement; let host: HTMLElement;
  let ready = $state(false);
  function render() {
    if (!img.complete || !img.naturalWidth) return;
    const r = host.getBoundingClientRect(); if (!r.width) return;
    const dpr = Math.max(1, Math.min(3, Math.round(window.devicePixelRatio || 1)));
    const cellPx = cell;
    const cols = Math.floor(r.width / cellPx), rows = Math.floor((r.width * (height / width)) / cellPx);
    host.style.height = rows * cellPx + 'px';
    snap(cellPx);
    const off = document.createElement('canvas'); off.width = cols; off.height = rows;
    const o = off.getContext('2d'); if (!o) return;
    const cs = getComputedStyle(host); const ink = cs.color; const paper = cs.backgroundColor;
    o.fillStyle = paper; o.fillRect(0, 0, cols, rows);
    // letterbox into the cell grid
    const scale = Math.min(cols / img.naturalWidth, rows / img.naturalHeight);
    const w = Math.round(img.naturalWidth * scale), h = Math.round(img.naturalHeight * scale);
    o.drawImage(img, Math.floor((cols - w) / 2), Math.floor((rows - h) / 2), w, h);
    const d = o.getImageData(0, 0, cols, rows).data;
    canvas.width = cols * cellPx * dpr; canvas.height = rows * cellPx * dpr; canvas.style.width = cols * cellPx + 'px'; canvas.style.height = rows * cellPx + 'px';
    const c = canvas.getContext('2d'); if (!c) return;
    c.fillStyle = paper; c.fillRect(0, 0, canvas.width, canvas.height); c.fillStyle = ink;
    const s = cellPx * dpr;
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      const i = (y * cols + x) * 4; const lum = (0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]) / 255;
      // slight contrast lift so mid-greys resolve into pattern rather than mush
      const v = Math.min(1, Math.max(0, (lum - 0.5) * 1.25 + 0.5));
      if (v < (BAYER8[y & 7][x & 7] + 0.5) / 64) c.fillRect(x * s, y * s, s, s);
    }
    ready = true;
  }
  // Snap the canvas origin to the page grid; the image shifts by under one cell.
  // Re-run whenever the document reflows, since the figure's page position can move.
  function snap(cellPx = cell) {
    const r = host.getBoundingClientRect();
    const pageX = r.left + window.scrollX, pageY = r.top + window.scrollY;
    const offX = ((pageX % cellPx) + cellPx) % cellPx, offY = ((pageY % cellPx) + cellPx) % cellPx;
    canvas.style.left = -offX + 'px'; canvas.style.top = -offY + 'px';
  }
  onMount(() => {
    const ro = new ResizeObserver(render); ro.observe(host);
    const body = new ResizeObserver(() => snap()); body.observe(document.body);
    if (img.complete) render();
    return () => { ro.disconnect(); body.disconnect(); };
  });
</script>
<figure class="pix" bind:this={host} class:ready>
  <img bind:this={img} {src} {alt} {width} {height} loading={eager ? 'eager' : 'lazy'} decoding="async" onload={render} />
  <canvas bind:this={canvas} aria-hidden="true"></canvas>
</figure>
<style>
.pix{position:relative;margin:0;width:100%;aspect-ratio:16/9;overflow:hidden;background:var(--paper);color:var(--fg)}
img{display:block;width:100%;height:100%;object-fit:contain;image-rendering:pixelated}
canvas{position:absolute;left:0;top:0;display:none;image-rendering:pixelated}
.ready img{opacity:0}.ready canvas{display:block}
</style>
