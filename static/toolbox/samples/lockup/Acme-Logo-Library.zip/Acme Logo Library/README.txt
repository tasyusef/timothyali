Acme — LOGO LIBRARY
=======================
Multi-format logo deliverable package. Structured as PRINT and WEB deliverables per
logo version (mirrors the ULC Logo Library convention).

------------------------------------------------------------
VERSIONS
------------------------------------------------------------
  01 Primary

------------------------------------------------------------
FOLDER STRUCTURE (per version)
------------------------------------------------------------
PRINT/
  Black/          EPS, JPEG (Large/Medium/Small), PDF      — 1-color black
  CMYK (Color)/   EPS, JPEG (Large/Medium/Small), PDF      — process color
  PMS (Color)/    EPS, PDF                                  — Pantone spot color
  White/          EPS, PDF                                  — white / reverse
WEB/
  Black/          JPEG, PNG, SVG (Large/Medium/Small)
  RGB (Color)/    JPEG, PNG, SVG (Large/Medium/Small)
  White/          PNG, SVG (Large/Medium/Small)            — no JPEG (white-on-white)

Sizes (longest edge): Large ~3000px, Medium ~1500px, Small ~600px
PNG = transparent. JPEG = flattened on white. SVG/EPS/PDF = vector (scale freely).

------------------------------------------------------------
COLOR
------------------------------------------------------------
  Color 1    HEX #FF683B   CMYK 0-59-77-0   1645 C
  Color 2    HEX #174C43   CMYK 70-0-12-70   3435 C

- WEB files use the HEX/RGB values.
- PRINT CMYK files use the CMYK values.
- PRINT PMS files carry true Pantone spot colors (Separation color space) with the CMYK
  values as fallback.

------------------------------------------------------------
NOTES
------------------------------------------------------------
- Clear space: keep generous clear space around the logo; don't crowd it.
- White versions have transparent backgrounds (PNG) / no background (vector) — for
  placement on dark or photographic backgrounds.
- The SVG and the original vector source are the authoritative artwork. EPS/PDF were
  generated to match it. If a vendor needs native Pantone swatches or an outlined .ai,
  produce it from the original Illustrator/vector source.